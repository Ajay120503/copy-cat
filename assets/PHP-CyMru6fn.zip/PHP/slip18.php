<!-- Write a menu driven program to perform the following operations on an associative array
a. Reverse the order of each element’s key-value pair.
b. Traverse the element in an array in random order.
c. Convert the array elements into individual variables.
d. Display the elements of an array along with key. -->

<?php
function reverseKeyValuePairs($array)
{
    $reversedArray = array();
    foreach ($array as $key => $value) {
        $reversedArray[$value] = $key;
    }
    return $reversedArray;
}

function traverseRandomOrder($array)
{
    $keys = array_keys($array);
    shuffle($keys);
    foreach ($keys as $key) {
        echo "Key: $key, Value: " . $array[$key] . "<br>";
    }
}

function convertToVariables($array)
{
    foreach ($array as $key => $value) {
        $$key = $value;
        echo "Variable \$$key created with value: " . $$key . "<br>";
    }
}

function displayArrayWithKeys($array)
{
    foreach ($array as $key => $value) {
        echo "Key: $key, Value: $value<br>";
    }
}

$assocArray = array(
    "first" => "John",
    "second" => "Jane",
    "third" => "Doe"
);
?>

<!DOCTYPE html>
<html>

<body>
    <form method="get">
        <input type="radio" name="operation" value="reverse" required> Reverse the order of key-value pairs<br>
        <input type="radio" name="operation" value="random"> Traverse elements in random order<br>
        <input type="radio" name="operation" value="variables"> Convert array elements into variables<br>
        <input type="radio" name="operation" value="display"> Display the elements with keys<br><br>
        <input type="submit" name="submit" value="Submit">
    </form>

    <h3>Result:</h3>
    <?php

    $operation = $_GET['operation'];

    switch ($operation) {
        case 'reverse':
            echo "Reversed key-value pairs:<br>";
            $reversedArray = reverseKeyValuePairs($assocArray);
            displayArrayWithKeys($reversedArray);
            break;

        case 'random':
            echo "Traversing in random order:<br>";
            traverseRandomOrder($assocArray);
            break;

        case 'variables':
            echo "Converting elements into variables:<br>";
            convertToVariables($assocArray);
            break;

        case 'display':
            echo "Displaying elements with keys:<br>";
            displayArrayWithKeys($assocArray);
            break;

        default:
            echo "Invalid operation.";
            break;
    }

    ?>
</body>

</html>