<!-- Slip24: Write a PHP program to read two file names from user and append content of first file into second file. -->

<?php
$firstFile = $_GET['firstFile'] ?? null; 
$secondFile = $_GET['secondFile'] ?? null; 

if ($firstFile && $secondFile) {
    if (file_exists($firstFile)) {
        $content = file_get_contents($firstFile);
        
        file_put_contents($secondFile, $content, FILE_APPEND);
        
        echo "Message : Content of '$firstFile' has been appended to '$secondFile'.";
    } else {
        echo "Message : The file '$firstFile' does not exist.";
    }
} else {
    echo "Message : Please enter both file names.";
}
?>

<!DOCTYPE html>
<html lang="en">
<body>
    <form method="get" action="">
        <label for="firstFile">Enter first file name:</label>
        <input type="text" id="firstFile" name="firstFile" required>
        <br><br>
        
        <label for="secondFile">Enter second file name:</label>
        <input type="text" id="secondFile" name="secondFile" required>
        <br><br>
        
        <input type="submit" value="Append Content">
    </form>
</body>
</html>