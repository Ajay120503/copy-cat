<!-- Create an array of 15 high temperatures (for example, in Celsius) -->

<?php
$highTemps = array(22, 18, 20, 21, 25, 23, 26, 19, 28, 24, 27, 22, 23, 21, 26);

echo "<p><strong>Temperatures:</strong></p>";
echo "<ul>";
foreach ($highTemps as $temp) {
    echo "<li>" . $temp . "°C</li>";
}
echo "</ul>";

$averageTemp = array_sum($highTemps) / count($highTemps);

rsort($highTemps);
$warmestTemps = array_slice($highTemps, 0, 5); 

echo "<h2>Weather Data for Spring Month</h2>";

echo "<p><strong>Average High Temperature:</strong> " . round($averageTemp, 2) . "°C</p>";

echo "<p><strong>Five Warmest High Temperatures:</strong></p>";
echo "<ul>";
foreach ($warmestTemps as $temp) {
    echo "<li>" . $temp . "°C</li>";
}
echo "</ul>";
?>
