<!-- Write a menu driven program to perform the following stack related operations:
a) Insert an element in stack
b) Delete an element from stack
c) Display the contents of stack -->

<?php
session_start();

if (!isset($_SESSION['stack'])) {
    $_SESSION['stack'] = [];
}

$element = $_GET['element'] ?? null;
$option = $_GET['option'] ?? null;

function stackInsert(&$stack, $element)
{
    array_push($stack, $element);
    echo "$element inserted into the stack.<br>";
}

function stackDelete(&$stack)
{
    if (!empty($stack)) {
        $element = array_pop($stack);
        echo "$element deleted from the stack.<br>";
    } else {
        echo "Stack is empty!<br>";
    }
}

function stackDisplay($stack)
{
    if (!empty($stack)) {
        echo "Stack contents: <br>";
        foreach ($stack as $elem) {
            echo "$elem<br>";
        }
    } else {
        echo "Stack is empty!<br>";
    }
}

switch ($option) {
    case '1':
        stackInsert($_SESSION['stack'], $element);
        break;
    case '2':
        stackDelete($_SESSION['stack']);
        break;
    case '3':
        stackDisplay($_SESSION['stack']);
        break;
}
?>

<!DOCTYPE html>
<html lang="en">

<body>
    <form method="get" action="">
        <label for="element">Element:</label>
        <input type="text" name="element" id="element"><br><br>

        <label for="option">Choose an operation:</label>
        <select name="option" id="option">
            <option value="1">Insert element in Stack</option>
            <option value="2">Delete element from Stack</option>
            <option value="3">Display Stack</option>
        </select><br><br>

        <input type="submit" value="Submit">
    </form>
</body>

</html>