<!-- Write a PHP script for the following: Design a form to accept two numbers from the user.
Give options to choose the arithmetic operation (use radio buttons). Display the result on the next
form. (Use the concept of function and default parameters. Use ‘include’ construct or require
statement) -->

<!DOCTYPE html>
<html lang="en">

<body>
    <h2>Simple Calculator</h2>
    <form method="get">
        <label for="num1">Enter the first number:</label><br>
        <input type="number" id="num1" name="num1" required><br><br>

        <label for="num2">Enter the second number:</label><br>
        <input type="number" id="num2" name="num2" required><br><br>

        <p>Select an operation:</p>
        <input type="radio" id="add" name="operation" value="add" checked>
        <label for="add">Addition</label><br>
        <input type="radio" id="subtract" name="operation" value="subtract">
        <label for="subtract">Subtraction</label><br>
        <input type="radio" id="multiply" name="operation" value="multiply">
        <label for="multiply">Multiplication</label><br>
        <input type="radio" id="divide" name="operation" value="divide">
        <label for="divide">Division</label><br><br>

        <input type="submit" value="Calculate">
    </form>

    <?php

    $num1 = floatval($_GET['num1']);
    $num2 = floatval($_GET['num2']);
    $operation = $_POST['operation'];
    function calculate($num1, $num2, $operation = 'add')
    {
        switch ($operation) {
            case 'add':
                return $num1 + $num2;
            case 'subtract':
                return $num1 - $num2;
            case 'multiply':
                return $num1 * $num2;
            case 'divide':
                return $num2 != 0 ? $num1 / $num2 : "Cannot divide by zero";
            default:
                return "Invalid operation";
        }
    }

    $result = calculate($num1, $num2, $operation);

    echo "<h3>Result:</h3>";
    echo "<p>The result of $operation between $num1 and $num2 is: $result</p>";
    ?>
</body>

</html>