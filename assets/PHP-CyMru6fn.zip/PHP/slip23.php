<!-- Write a PHP script for the following: Design a form to accept the marks of 5 different
subjects of a student, having serial number, subject name & marks out of 100. Display the result
in the tabular format which will have total, percentage and grade. Use only 3 text boxes.(Use
array of form parameters) -->

<!DOCTYPE html>
<html>

<head>
    <title>Student Marks Entry</title>
    <style>
        table,
        th,
        td {
            border: 1px solid black;
            border-collapse: collapse;
            padding: 8px;
            text-align: center;
        }
    </style>
</head>

<body>

    <h2>Enter Marks for 5 Subjects</h2>

    <form method="post">
        <label>Serial Numbers (comma separated):</label>
        <input type="text" name="serial_numbers" required><br><br>

        <label>Subject Names (comma separated):</label>
        <input type="text" name="subject_names" required><br><br>

        <label>Marks (comma separated):</label>
        <input type="text" name="marks" required><br><br>

        <input type="submit" name="submit" value="Submit">
    </form>

    <?php
    $serialNumbers = explode(',', $_POST['serial_numbers']);
    $subjectNames = explode(',', $_POST['subject_names']);
    $marks = explode(',', $_POST['marks']);

    if (count($serialNumbers) == 5 && count($subjectNames) == 5 && count($marks) == 5) {
        $totalMarks = array_sum($marks);
        $percentage = ($totalMarks / 500) * 100;

        if ($percentage >= 90) {
            $grade = 'A';
        } elseif ($percentage >= 75) {
            $grade = 'B';
        } elseif ($percentage >= 50) {
            $grade = 'C';
        } elseif ($percentage >= 35) {
            $grade = 'D';
        } else {
            $grade = 'F';
        }

        echo "<h3>Result</h3>";
        echo "<table>";
        echo "<tr><th>Serial No.</th><th>Subject Name</th><th>Marks (out of 100)</th></tr>";

        for ($i = 0; $i < 5; $i++) {
            echo "<tr>";
            echo "<td>" . trim($serialNumbers[$i]) . "</td>";
            echo "<td>" . trim($subjectNames[$i]) . "</td>";
            echo "<td>" . trim($marks[$i]) . "</td>";
            echo "</tr>";
        }

        echo "<tr><td colspan='2'><strong>Total Marks</strong></td><td>$totalMarks / 500</td></tr>";
        echo "<tr><td colspan='2'><strong>Percentage</strong></td><td>" . round($percentage, 2) . "%</td></tr>";
        echo "<tr><td colspan='2'><strong>Grade</strong></td><td>$grade</td></tr>";
        echo "</table>";
    } else {
        echo "<p>Please enter exactly 5 serial numbers, subject names, and marks.</p>";
    }

    ?>

</body>

</html>