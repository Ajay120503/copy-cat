<!-- Write a PHP script to accept 2 strings from the user, the first string should be a sentence and
second can be a word.
a. Delete a small part from first string after accepting position and number of characters to
remove.
b. Insert the given small string in the given big string at specified position without removing
any characters from the big string.
c. Replace some characters/ words from given big string with the given small string at
specified position. -->

<!DOCTYPE html>
<html>

<body>

    <h2>String Operations</h2>
    <form method="get">
        <label>Enter a sentence (big string):</label><br>
        <input type="text" name="big_string" required><br><br>

        <label>Enter a word (small string):</label><br>
        <input type="text" name="small_string" required><br><br>

        <h3>Choose an Operation:</h3>

        <input type="radio" name="operation" value="delete" required>
        Delete part of the sentence<br>
        <label>Position to start deletion:</label>
        <input type="number" name="start_position" min="0"><br>
        <label>Number of characters to delete:</label>
        <input type="number" name="delete_length" min="0"><br><br>

        <input type="radio" name="operation" value="insert">
        Insert small string into the sentence at a specified position<br>
        <label>Position to insert:</label>
        <input type="number" name="insert_position" min="0"><br><br>

        <input type="radio" name="operation" value="replace">
        Replace part of the sentence with the word at a specified position<br>
        <label>Position to start replacement:</label>
        <input type="number" name="replace_position" min="0"><br>
        <label>Length of replacement:</label>
        <input type="number" name="replace_length" min="0"><br><br>

        <input type="submit" name="submit" value="Submit">
    </form>

    <h3>Result:</h3>
    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $bigString = $_GET['big_string'];
        $smallString = $_GET['small_string'];
        $operation = $_GET['operation'];

        switch ($operation) {
            case 'delete':
                $startPosition = (int) $_GET['start_position'];
                $deleteLength = (int) $_GET['delete_length'];
                if ($startPosition < 0 || $deleteLength < 0) {
                    echo "Invalid input for deletion.";
                } else {
                    $modifiedString = substr_replace($bigString, '', $startPosition, $deleteLength);
                    echo "Modified string after deletion: $modifiedString";
                }
                break;

            case 'insert':
                $insertPosition = (int) $_GET['insert_position'];
                if ($insertPosition < 0) {
                    echo "Invalid input for insertion.";
                } else {
                    $modifiedString = substr_replace($bigString, $smallString, $insertPosition, 0);
                    echo "Modified string after insertion: $modifiedString";
                }
                break;

            case 'replace':
                $replacePosition = (int) $_GET['replace_position'];
                $replaceLength = (int) $_GET['replace_length'];
                if ($replacePosition < 0 || $replaceLength < 0) {
                    echo "Invalid input for replacement.";
                } else {
                    $modifiedString = substr_replace($bigString, $smallString, $replacePosition, $replaceLength);
                    echo "Modified string after replacement: $modifiedString";
                }
                break;

            default:
                echo "Invalid operation.";
                break;
        }
    }
    ?>
</body>

</html>