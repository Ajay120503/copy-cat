<!-- Write a menu driven program to perform the following operations on associative arrays:

a) Split an array into chunks
b) Sort the array by values without changing the keys.
c) Filter the odd elements from an array.
 -->

<?php
$array1 = array("Sophia" => "31", "Jacob" => "41", "William" => "39", "Ramesh" => "40");
$array2 = array("Sophia" => "31", "Emily" => "22", "Jacob" => "41", "Ramesh" => "40");
$option = $_GET['option'] ?? null; 

function splitArrayIntoChunks($array)
{
    $chunks = array_chunk($array, 2, true); 
    print_r($chunks);
}

function sortArrayByValues($array)
{
    asort($array); 
    print_r($array);
}

function filterOddElements($array)
{
    $filtered = array_filter(
        $array,
        function ($value) {
            return $value % 2 != 0; 
        }
    );
    print_r($filtered);
}


switch ($option) {
    case 'a':
        splitArrayIntoChunks($array1);
        break;
    case 'b':
        sortArrayByValues($array1);
        break;
    case 'c':
        filterOddElements($array1);
        break;
    default:
        echo "Please choose a valid option.";
}
?>

<!DOCTYPE html>
<html lang="en">

<body>
    <form method="get" action="">
        <label for="option">Select an option:</label>
        <select name="option" id="option">
            <option value="a">Split array into chunks</option>
            <option value="b">Sort array by values</option>
            <option value="c">Filter odd elements from array</option>
        </select>
        <br><br>
        <input type="submit" value="Submit">
    </form>
</body>

</html>