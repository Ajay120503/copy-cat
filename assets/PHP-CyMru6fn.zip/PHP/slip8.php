<!-- :Write a PHP script for the following: Design a form to accept two strings from the user.
a. Find whether the small string appears at the start of the large string.
b. Find the position of the small string in the big string.
c. Compare both the string for first n characters, also the comparison should not be case
sensitive. -->

<!DOCTYPE html>
<html lang="en">

<body>
    <form action="" method="get">
        Enter the big String : <input type="text" name="string1" /><br>
        Enter the small String : <input type="text" name="string2" /><br>
        Enter the compare characters count : <input type="text" name="num" /><br>

        <input type="radio" name="option" value="1"/>a. Find whether the small string appears at the start of the large string.<br>
        <input type="radio" name="option" value="2"/>b. Find the position of the small string in the big string.<br>
        <input type="radio" name="option" value="3"/>c. Compare both the string for first n characters, also the comparison should not be case<br>

        <input type="submit" value="submit" />
    </form>
</body>

</html>

<?php

$bid_string = $_GET['string1'];
$small_string = $_GET['string2'];
$num = intval($_GET['num']);
$option = $_GET['option'];

function startsWith($bid_string, $small_string)
{
    if (strpos($bid_string, $small_string) === 0) {
        echo "string is present at the start";
    } else {
        echo "string is not present at the start";

    }
}

function findSubstringPosition($bid_string, $small_string)
{
    $position = strpos($bid_string, $small_string);
    if ($position !== false) {
        echo "string is present at the index $position";
    } else {
        echo "string is not present";
    }
}
function compareStrings($bid_string, $small_string, $num)
{
    if (strncasecmp($bid_string, $small_string, $num) === 0) {
        echo "The first $num characters of both strings are equal (case-insensitive).<br>";
    } else {
        echo "The first $num characters of both strings are not equal (case-insensitive).<br>";
    }
}

switch ($option) {
    case '1':
        startsWith($bid_string, $small_string);
        break;
    case '2':
        findSubstringPosition($bid_string, $small_string);
        break;
    case '3':
        compareStrings($bid_string, $small_string, $num);
        break;
}

?>