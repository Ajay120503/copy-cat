<!-- Write a PHP script for the following: Design a form having a text box and a drop down list
containing any 3 separators(e.g. #, |, %, @, ! or comma) accept a strings from the user and also a
separator.
a. Split the string into separate words using the given separator.
b. Replace all the occurrences of separator in the given string with some other separator.
c. Find the last word in the given string(Use strrstr() function). -->


<!DOCTYPE html>
<html lang="en">

<body>
    <form action="" method="get">
        Enter the String : <input type="text" name="string" /><br>

        <label>Select the exit Seperator in string</label>
        <select name="separator">
            <option value="#">#</option>
            <option value="|">|</option>
            <option value="%">%</option>
            <option value="@">@</option>
            <option value="!">!</option>
            <option value=",">,</option>
        </select><br>

        <label>Select the new Seperator</label>
        <select name="newseparator">
            <option value="#">#</option>
            <option value="|">|</option>
            <option value="%">%</option>
            <option value="@">@</option>
            <option value="!">!</option>
            <option value=",">,</option>
        </select><br>

        <input type="radio" name="option" value="1" />a. Splitthe string into separate words using the given separator.<br>
        <input type="radio" name="option" value="2" />b. Replace all the occurrences of separator in the given string with some other separator.<br>
        <input type="radio" name="option" value="3" />c. Find the last word in the given string(Use strrstr() function).<br>

        <input type="submit" value="submit" />
    </form>
</body>

</html>

<?php
$string = $_GET['string'];
$separator = $_GET['separator'];
$newSeparator = $_GET['newseparator'];
$option = $_GET['option'];

function splitString($string, $separator)
{
    $words = explode($separator, $string);
    echo " words : <br>";
    foreach ($words as $word) {
        echo $word . "<br>";
    }
}

function replaceAllOccurrences($separator, $newSeparator, $string)
{

    $replacedString = str_replace($separator, $newSeparator, $string);
    echo "replace separator with words : $replacedString";
}

function findLastWord($string, $separator)
{
    $lastSpacePos = strrpos($string, $separator);

    if ($lastSpacePos === false) {
        $lastWord = $string;
    } else {
        $lastWord = substr($string, $lastSpacePos + 1);
    }

    echo "Last word of string: " . $lastWord;
}

switch ($option) {
    case "1":
        splitString($string, $separator);
        break;
    case "2":
        replaceAllOccurrences($separator, $newSeparator, $string);
        break;
    case "3":
        findLastWord($string, $separator);
        break;
}
?>