<!-- Write a PHP script to sort the following associative array :
array(“Sagar"=>"31","Vicky"=>"41","Leena"=>"39","Ramesh"=>"40") in
a) ascending order sort by Value
b) ascending order sort by Key
c) descending order sorting by Value
d) descending order sorting by Key -->

<?php
$array = array("Sophia"=>"31", "Jacob"=>"41", "William"=>"39", "Ramesh"=>"40");

asort($array);
echo "Ascending order by value: ";
print_r($array);

echo "<br>";

ksort($array);
echo "Ascending order by key: ";
print_r($array);

echo "<br>";

arsort($array);
echo "Descending order by value: ";
print_r($array);

echo "<br>";

krsort($array);
echo "Descending order by key: ";
print_r($array);
?>