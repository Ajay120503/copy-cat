<!-- Design a form to accept string from the user and perform the following operations
a. To select first 5 words from the string
b. Convert the given string to lowercase and then to Title case.
c. Pad the given string with “*” from left and right both the sides.
d. Remove the leading whitespaces from the given string.
e. Find the reverse of given string. -->


<!DOCTYPE html>
<html lang="en">

<body>
    <form action="" method="get">
        Enter the String : <input type="text" name="string" /><br>

        <input type="radio" name="option" value="1"/>a. Write a function to find the length of given string without using built in functions.<br>
        <input type="radio" name="option" value="2"/>b. Write a function to count the total number of vowels i.e. (a,e,i,o,u)from the string.<br>
        <input type="radio" name="option" value="3"/>c. Convert the given string to lowercase and then to Title case.<br>
        <input type="radio" name="option" value="4"/>d. Pad the given string with “*” from left and right both the sides.<br>
        <input type="radio" name="option" value="5"/>e. Remove the leading whitespaces from57the given string.<br>
        <input type="radio" name="option" value="6"/>f. Find the reverse of given string.(use built-in functions)<br>

        <input type="submit" value="submit" />
    </form>
</body>

</html>

<?php
$string = $_GET['string'];
$option = $_GET['option'];

function string_lenght($string)
{
    $count = 0;
    while (isset($string[$count])) {
        $count++;
    }
    echo "string lenght : " . $count;
}

function vowelsCount($string)
{
    $vowel_count = 0;

    $string = strtolower($string);

    $vowels = ['a', 'e', 'i', 'o', 'u'];

    for ($i = 0; isset($string[$i]); $i++) {
        if (in_array($string[$i], $vowels)) {
            $vowel_count++;
        }
    }

    echo "vowel count : " . $vowel_count;
}

function toTitleCase($string)
{
    $lowercase_string = strtolower($string);

    $title_case_string = ucwords($lowercase_string);

    echo "Original string: " . $string . "<br>";
    echo "Title case string: " . $title_case_string;
}

function padString($string)
{
    $padded_string = str_pad($string, strlen($string)+4, "*", STR_PAD_BOTH);

    echo "String padding : ".$padded_string;
}

function removeLeadingWhitespaces($string)
{
    $trimmed_string = ltrim($string);
    
    echo "without leading space String : ". $trimmed_string;
}

function reverseString($string)
{
    $reversed_string = strrev($string);
    
    echo "Reverse String : ". $reversed_string;
}

switch ($option) {
    case '1':
        string_lenght($string);
        break;
    case '2':
        vowelsCount($string);
        break;
    case '3':
        toTitleCase($string);
        break;
    case '4':
        padString($string);
        break;
    case '5':
        removeLeadingWhitespaces($string);
        break;
    case '6':
        reverseString($string);
        break;
}

?>
