<!-- /*Write a script to accept two integers(Use html form having 2 textboxes). 
Write a PHP script to, 
a. Find mod of the two numbers. 
b. Find the power of first number raised to the second. 
c. Find the sum of first n numbers (considering first number as n) 
d. Find the factorial of second number. 
(Write separate function for each of the above operations.) */ -->


<!DOCTYPE html>
<html lang="en">
<body>
    <form action="" method="get">
        Enter the first number : <input type="text" name="num1"/><br>
        Enter the second number : <input type="text" name="num2"/><br>

        <input type="radio" name="option" value="1"/>a. Find mod of the two numbers. <br>
        <input type="radio" name="option" value="2"/>b. Find the power of first number raised to the second.<br>
        <input type="radio" name="option" value="3"/>c. Find the sum of first n numbers (considering first number as n)<br>
        <input type="radio" name="option" value="4"/>d. Find the factorial of second number. <br>
        <input type="submit" value="submit"/>
    </form>
</body>
</html>

<?php

$num1 = $_GET['num1'];
$num2 = $_GET['num2'];
$op = $_GET['option'];
function mod_($num1, $num2)
{
    echo "mode :" . $num1 % $num2;
}

function power_($num1, $num2)
{
    echo "power : " . $num1 ** $num2;
}

function sum_($num1)
{
    $sum = array_sum(range(1, $num1));
    echo "sum : " . $sum;
}

function factorial_($num2)
{
    $fact = 1;
    for ($i = 2; $i <= $num2; $i++) {
        $fact *= $i;
    }
    echo "factorial : " . $fact;
}

switch ($op) {
    case '1':
        mod_($num1, $num2);
        break;
    case '2':
        power_($num1, $num2);
        break;
    case '3':
        sum_($num1);
        break;
    case '4':
        factorial_($num2);
        break;
}

?>