<!-- Write a menu driven program to perform the following queue related operations
a) Insert an element in queue
b) Delete an element from queue
c) Display the contents of queue -->

<?php
session_start();

if (!isset($_SESSION['queue'])) {
    $_SESSION['queue'] = [];
}

$element = $_GET['element'] ?? null;
$option = $_GET['option'] ?? null;

function queueInsert(&$queue, $element)
{
    array_unshift($queue, $element);
    echo "$element inserted into the queue.<br>";
}

function queueDelete(&$queue)
{
    if (!empty($queue)) {
        $element = array_pop($queue);
        echo "$element deleted from the queue.<br>";
    } else {
        echo "Queue is empty!<br>";
    }
}
function queueDisplay($queue)
{
    if (!empty($queue)) {
        echo "Queue contents: <br>";
        foreach ($queue as $elem) {
            echo "$elem ";
        }
    } else {
        echo "Queue is empty!<br>";
    }
}

switch ($option) {
    case '1':
        queueInsert($_SESSION['queue'], $element);
        break;
    case '2':
        queueDelete($_SESSION['queue']);
        break;
    case '3':
        queueDisplay($_SESSION['queue']);
        break;
    default:
        echo "Please select a valid option.<br>";
        break;
}
?>

<!DOCTYPE html>
<html lang="en">

<body>
    <form method="get" action="">
        <label for="element">Element:</label>
        <input type="text" name="element" id="element"><br><br>

        <label for="option">Choose an operation:</label>
        <select name="option" id="option">
            <option value="1">Insert element in Queue</option>
            <option value="2">Delete element from Queue</option>
            <option value="3">Display Queue</option>
        </select><br><br>

        <input type="submit" value="Submit">
    </form>
</body>

</html>