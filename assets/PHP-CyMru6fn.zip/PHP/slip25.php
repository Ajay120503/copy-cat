<!-- Write a menu driven program to perform various file operations. Accept filename from
user.
a) Display type of file.
b) Display last modification time of file
c) Display the size of file
d) Delete the file -->

<?php
$filename = $_GET['filename'] ?? null;
$option = $_GET['option'] ?? null;

if ($filename && file_exists($filename)) {
    switch ($option) {
        case 'a':
            echo "File type: " . filetype($filename);
            break;

        case 'b':
            echo "Last modification time: " . date("F d Y H:i:s.", filemtime($filename));
            break;

        case 'c':
            echo "File size: " . filesize($filename) . " bytes";
            break;
        case 'd':
            unlink($filename);
            echo "File is Deleted";
            break;
        default:
            echo "Please choose a valid option.";
    }
} else {
    echo "File does not exist or filename not provided.";
}
?>

<!DOCTYPE html>
<html lang="en">

<body>
    <form method="get" action="">
        <label for="filename">Enter filename:</label>
        <input type="text" id="filename" name="filename" required>
        <br><br>

        <label for="option">Choose an option:</label>
        <select name="option" id="option">
            <option value="a">Display type of file</option>
            <option value="b">Display last modification time of file</option>
            <option value="c">Display the size of file</option>
            <option value="d">Delete the file</option>
        </select>
        <br><br>

        <input type="submit" value="Submit">
    </form>
</body>

</html>