public class TrafficSignal extends Thread{
  public void run(){
    try{
      while(true){
        System.out.println("  RED ");
        Thread.sleep(3000);
        
        System.out.println("YELLOW");
        Thread.sleep(1000);
        
        System.out.println(" GREEN");
        Thread.sleep(3000);
      }
    }catch(InterruptedException e){}
  
  }
  public static void main(String args[]){
    new TrafficSignal().start();
  }
}
