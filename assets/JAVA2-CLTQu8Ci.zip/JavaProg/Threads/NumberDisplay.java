import javax.swing.*;

public class NumberDisplay implements Runnable {
    JTextField text = new JTextField(10);
    
    public void run() {
        for (int i = 1; i <= 100; i++) {
            text.setText(i + "");
            try { 
              Thread.sleep(1000); 
            } catch (Exception e) {}
        }
    }

    public static void main(String[] args) {
        JFrame f = new JFrame();
        NumberDisplay nd = new NumberDisplay();
        JButton b = new JButton("Start");
        b.addActionListener(e -> new Thread(nd).start());

        f.add(nd.text); f.add(b);
        f.setLayout(new java.awt.FlowLayout());
        f.setSize(200, 100); f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}

