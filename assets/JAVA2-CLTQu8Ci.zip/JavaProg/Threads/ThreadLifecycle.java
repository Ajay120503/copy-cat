import java.util.Random;

class MyThread extends Thread {
    MyThread(String name) { super(name); }

    public void run() {
        int sleepTime = new Random().nextInt(5000);
        
        System.out.println(getName() + " sleeping for " + sleepTime + " ms.");
        try { 
          Thread.sleep(sleepTime); 
        } catch (InterruptedException e) {}
  
        System.out.println(getName() + " finished.");
    }
}

public class ThreadLifecycle {
    public static void main(String[] args) {
        new MyThread("Thread-1").start();
        new MyThread("Thread-2").start();
        new MyThread("Thread-3").start();
    }
}

