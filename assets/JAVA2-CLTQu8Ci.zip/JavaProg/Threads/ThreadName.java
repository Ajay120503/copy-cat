public class ThreadName extends Thread {

    public void run() {
        System.out.println("Current Thread: " + getName());
    }

    public static void main(String[] args) {
        new ThreadName().start();
        new ThreadName().start();
    }
}

