class PrintThread extends Thread {
    String text; int count;

    PrintThread(String text, int count) {
        this.text = text;
        this.count = count;
    }

    public void run() {
        for (int i = 0; i < count; i++)
            System.out.println(text);
    }
}

public class MultiThreadPrint {
    public static void main(String[] args) {
        new PrintThread("COVID19", 10).start();
        new PrintThread("LOCKDOWN2020", 20).start();
        new PrintThread("VACCINATED2021", 30).start();
    }
}

