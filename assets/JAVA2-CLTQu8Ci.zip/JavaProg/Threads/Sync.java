class Table {
    synchronized void print(int n) {
        for (int i = 1; i <= 5; i++) {
            System.out.println(n * i);
            try {
              Thread.sleep(500); 
            } catch (Exception e) {}
        }
    }
}

public class Sync {
    public static void main(String[] args) {
        Table t = new Table();
        new Thread(() -> t.print(2)).start();
        new Thread(() -> t.print(3)).start();
    }
}

