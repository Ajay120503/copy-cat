import javax.swing.*;
import java.awt.*;

public class BallMover extends JPanel {
    int y = 10, direction = 5;

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.fillOval(50, y, 30, 30);
    }

    void moveBall() {
        new Thread(() -> {
            while (true) {
                y += direction;
                if (y >= getHeight() - 30 || y <= 0) direction *= -1;
                repaint();
                try { Thread.sleep(20); } catch (Exception e) {}
            }
        }).start();
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ball Animation");
        BallMover ball = new BallMover();
        JButton start = new JButton("Start");

        start.addActionListener(e -> ball.moveBall());

        frame.add(ball);
        frame.add(start, BorderLayout.SOUTH);
        frame.setSize(200, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}

