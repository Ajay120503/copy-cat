public class ThreadInfo extends Thread{

	public void run() {
        System.out.println("Name: " + getName() + ", Priority: " + getPriority());
    }
	
    public static void main(String[] args) {
        ThreadInfo t = new ThreadInfo();
        t.setName("TestThread");
        t.setPriority(7);
        t.setPriority(1);
        t.start();
    }
}

