import java.io.File;
import java.util.Scanner;
class SearchThread extends Thread {
    File file;
    String searchTerm;

    SearchThread(File file, String searchTerm) {
        this.file = file;
        this.searchTerm = searchTerm;
    }

    public void run() {
        try (Scanner scanner = new Scanner(file)) {
            int lineNum = 1;
            while (scanner.hasNextLine()) {
                if (scanner.nextLine().contains(searchTerm))
                    System.out.println(file.getName() + " - Line " + lineNum);
                lineNum++;
            }
        } catch (Exception e) {}
    }
}
public class Search {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter text to search: ");
        String searchTerm = input.nextLine();
        input.close();
        for (File file : new File(".").listFiles((d, n) -> n.endsWith(".txt")))
            new SearchThread(file, searchTerm).start();
    }
}

