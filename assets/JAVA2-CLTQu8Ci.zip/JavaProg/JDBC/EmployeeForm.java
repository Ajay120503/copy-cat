import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class EmployeeForm extends JFrame {
    private JTextField txtEno, txtEName, txtSalary;
    private JButton btnSave;

    public EmployeeForm() {
        setTitle("Employee Form");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 2));

        add(new JLabel("Emp No:"));
        txtEno = new JTextField();
        add(txtEno);

        add(new JLabel("Name:"));
        txtEName = new JTextField();
        add(txtEName);

        add(new JLabel("Salary:"));
        txtSalary = new JTextField();
        add(txtSalary);

        btnSave = new JButton("Save");
        add(btnSave);
        btnSave.addActionListener(e -> saveEmployee());
    }

    private void saveEmployee() {
        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/your_db", "user", "pass")) {
            PreparedStatement pst = con.prepareStatement("INSERT INTO employees VALUES (?, ?, ?)");
            pst.setInt(1, Integer.parseInt(txtEno.getText()));
            pst.setString(2, txtEName.getText());
            pst.setDouble(3, Double.parseDouble(txtSalary.getText()));
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Saved!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new EmployeeForm().setVisible(true));
    }
}

