import java.io.*;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/SearchCustomerServlet")
public class SearchCustomerServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        PrintWriter out = res.getWriter();
        int custNo = Integer.parseInt(req.getParameter("customer_number"));

        try {
            Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/yourDB", "yourUser", "yourPass");
            PreparedStatement ps = con.prepareStatement("SELECT name FROM customer WHERE customer_number=?");
            ps.setInt(1, custNo);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) out.println("Customer Found: " + rs.getString("name"));
            else out.println("Customer Not Found!");
            con.close();
        } catch (Exception e) {
            out.println("Error: " + e.getMessage());
        }
    }
}

/*
index.html

<!DOCTYPE html>
<html>
<head><title>Customer Search</title></head>
<body>
    <form action="SearchCustomerServlet" method="post">
        Customer Number: <input type="text" name="customer_number" required>
        <input type="submit" value="Search">
    </form>
</body>
</html>


*/
