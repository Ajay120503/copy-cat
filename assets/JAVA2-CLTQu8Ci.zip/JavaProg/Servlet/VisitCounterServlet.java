import java.io.IOException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/VisitCounter")
public class VisitCounterServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        int count = 1;
        Cookie[] cookies = req.getCookies();
        if (cookies != null) {
            for (Cookie c : cookies)
                if (c.getName().equals("count")) count = Integer.parseInt(c.getValue()) + 1;
        }
        res.addCookie(new Cookie("count", String.valueOf(count)));
        res.getWriter().println(count == 1 ? "Welcome! First visit." : "Visit count: " + count);
    }
}

