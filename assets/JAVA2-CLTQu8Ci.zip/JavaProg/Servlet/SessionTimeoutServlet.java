import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/SessionTimeoutServlet")
public class SessionTimeoutServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();

        HttpSession session = req.getSession();

        session.setMaxInactiveInterval(300);

        out.println("<h3>Session timeout set to 5 minutes.</h3>");
    }
}

