import java.util.*;

public class SortedNumbers {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TreeSet<Integer> numbers = new TreeSet<>();

        System.out.print("Enter how many numbers: ");
        int n = sc.nextInt();

        System.out.println("Enter numbers:");
        while (n-- > 0) {
            numbers.add(sc.nextInt());
        }

        System.out.println("Sorted Unique Numbers: " + numbers);

        System.out.print("Enter number to search: ");
        System.out.println(numbers.contains(sc.nextInt()) ? "Found" : "Not Found");

    }
}

