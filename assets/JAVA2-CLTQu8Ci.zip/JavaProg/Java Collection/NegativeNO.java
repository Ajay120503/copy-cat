import java.util.*;

public class NegativeNO{
  public static void main(String args[]){
    
    LinkedList<Integer> list = new LinkedList<>();
    Scanner sc = new Scanner(System.in);
    
    System.out.print("Enter the no. count : ");
    int n = sc.nextInt();
    
    System.out.print("Enter the numbers : ");
    for(int i=0; i < n; i++){
      int num = sc.nextInt();
      
      if(num < 0)
        list.add(num);
    }
    
    System.out.println("Negative no. list is :"+list);
    
  }
}
