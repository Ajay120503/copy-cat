import java.util.*;

public class List{
  public static void main(String args[]){
    
    ArrayList<String> list = new ArrayList<>();
    
    list.add("Ram"); // add the element in the array list
    list.add("Radha");
    list.add("Ravan");
    
    list.set(2,"Hanuman"); // update the index value
    
    list.remove(1); // remove the index value
    
    Iterator<String> i = list.iterator();
    while(i.hasNext())
      System.out.println(i.next());
  }
}

