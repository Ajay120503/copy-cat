import java.util.*;

public class CMDName{
  public static void main(String args[]){
    
    ArrayList<String> names = new ArrayList<>(Arrays.asList(args));
    
      System.out.println("Display By Iterator : ");
      Iterator<String> i = names.iterator();
      while(i.hasNext())
        System.out.println(i.next());
      
      System.out.println("Display By ListIterator : ");
      ListIterator<String> li = names.listIterator(names.size());
      while(li.hasPrevious())
        System.out.println(li.previous());
    
  }
}
