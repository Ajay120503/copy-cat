import java.util.*;

public class Colors{
  public static void main(String args[]){
    TreeSet<String> tree = new TreeSet<>();
    
    tree.add("Red");
    tree.add("Yellow");
    tree.add("Orange");
    tree.add("Blue");
    
    Iterator<String> i = tree.iterator();
    while(i.hasNext())
      System.out.println(i.next());
    
    Iterator<String> j = tree.descendingIterator();
    while(j.hasNext())
      System.out.println(j.next());
    
  }
}
