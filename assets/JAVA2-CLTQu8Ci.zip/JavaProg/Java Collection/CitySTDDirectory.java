import java.util.*;

public class CitySTDDirectory{
  public static void main(String args[]){
  
    HashMap<String, Integer> cityMap = new HashMap<>();
    Scanner sc = new Scanner(System.in);
    
    cityMap.put("Mumbai", 22);
    cityMap.put("Delhi", 11);
    cityMap.put("Bangalore", 80);
    cityMap.put("Chennai", 44);
    
    System.out.println("----- Menu -----\n1. Insert\n2. Delete\n3. Search\n4. Display\n5. Exit\n\n");
    while(true){
    
      String city;
      int code;
      System.out.print("\n-------------------------------\nEnter the Option : ");
      int option = sc.nextInt();
      sc.nextLine();
      
      switch(option){
        case 1:
          System.out.print("Enter the City name : ");
          city = sc.nextLine();
          System.out.print("Enter the STD code : ");
          code = sc.nextInt();
          sc.nextLine();
          cityMap.put(city , code);
          break;
        case 2:
          System.out.print("Enter the City name : ");
          city = sc.nextLine();
          
          if(cityMap.remove(city) != null)
            System.out.print("Deleted !!!");
          else
            System.out.print("not found !!!");
          break;
        case 3:
          System.out.print("Search the City name : ");
          city = sc.nextLine();
          
          if(cityMap.containsKey(city))
            System.out.println("Found : "+cityMap.get(city));
          else 
            System.out.println("Not Found");
          break; 
        case 4:
          System.out.println("City Name\t\tSTD Code");
          cityMap.forEach((city_, code_) -> System.out.println(city_+"\t\t"+code_));
          break;
        case 5:
          System.exit(0);
      }
    } 
  }
}
