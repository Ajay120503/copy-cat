import java.util.*;

public class LinkList{
  public static void main(String args[]){
    
    LinkedList<String> l = new LinkedList<>();
    
    l.add("Ajay");
    l.addFirst("Sadhana");
    l.addLast("Kandhare");
    
    Iterator<String> i = l.iterator();
    while(i.hasNext())
      System.out.println(i.next());
  }
}
