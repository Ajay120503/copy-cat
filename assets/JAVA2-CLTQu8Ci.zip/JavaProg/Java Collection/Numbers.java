import java.util.*;
public class Numbers{
   public static void main(String args[]){
      
      TreeSet<Integer> numbers = new TreeSet<>();
      Scanner sc = new Scanner(System.in);
      
      System.out.print("Enter the no. you want to insert the no. in the Set : ");
      int n = sc.nextInt();
      
      System.out.println("Enter the "+n+" numbers :");
      for(int i=0; i < n; i++){
        int num = sc.nextInt();
        if(!numbers.add(num))
          System.out.println("Number is Duplicate !!!");
      }
      
      System.out.println("Tree set is :");
      Iterator i = numbers.iterator();
      while(i.hasNext())
        System.out.printf("%d ",i.next());
   }
}
