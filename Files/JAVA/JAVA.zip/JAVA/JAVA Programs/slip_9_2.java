// Slip 9:
//Q2
// Write a program to using marker interface create a class Product (product_id, product_name,
// product_cost, product_quantity) default and parameterized constructor. Create objects of class
// product and display the contents of each object and Also display the object count.

interface ProductMarker {
}

class Product implements ProductMarker {
    private int productId;
    private String productName;
    private double productCost;
    private static int productCount = 0;

    public Product(int productId, String productName, double productCost) {
        this.productId = productId;
        this.productName = productName;
        this.productCost = productCost;
        productCount++;
    }

    public void display() {
        System.out.printf("ID: %d, Name: %s, Cost: %.2f%n", productId, productName, productCost);
    }

    public static int getProductCount() {
        return productCount;
    }
}

public class slip_9_2 {
    public static void main(String[] args) {
        Product product1 = new Product(1, "Laptop", 799.99);
        Product product2 = new Product(2, "Smartphone", 499.99);
        Product product3 = new Product(3, "Tablet", 299.99);

        product1.display();
        product2.display();
        product3.display();

        System.out.println("Total products: " + Product.getProductCount());
    }
}
