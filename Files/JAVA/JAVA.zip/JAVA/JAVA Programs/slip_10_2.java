import student.StudentInfo;

public class slip_10_2 {
    public static void main(String[] args) {
        StudentInfo studentInfo = new StudentInfo();
        studentInfo.acceptDetails();

        double percentage = calculatePercentage(studentInfo.marks);
        System.out.printf("Percentage: %.2f%%\n", percentage);
    }

    public static double calculatePercentage(int[] marks) {
        int total = 0;
        for (int mark : marks) {
            total += mark;
        }
        return total / 6.0; 
    }
}
