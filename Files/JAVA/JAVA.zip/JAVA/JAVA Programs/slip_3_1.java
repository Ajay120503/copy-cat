// Slip 3 :
//Q1
// Write a program to accept n name of cities from the user and sort them in ascending order.

import java.util.Scanner;
import java.util.Arrays;

public class slip_3_1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of cities: ");
        int n = scanner.nextInt();
        scanner.nextLine();

        String[] cities = new String[n];

        for (int i = 0; i < n; i++) {
            System.out.print("Enter name of city " + (i + 1) + ": ");
            cities[i] = scanner.nextLine();
        }

        Arrays.sort(cities); //Arrays.sort(cities, Comparator.reverseOrder()); for descending order

        System.out.println("\nCities in ascending order:");
        for (String city : cities) {
            System.out.println(city);
        }

        scanner.close();
    }
}
