// Slip 8:
//Q2
// Design a screen to handle the Mouse Events such as MOUSE_MOVED
// and MOUSE_CLICKED and display the position of the Mouse_Click in a TextField.

import java.awt.*;
import java.awt.event.*;

public class slip_8_2 extends Frame implements MouseMotionListener, MouseListener {
    private TextField textField;

    public slip_8_2() {

        setTitle("Mouse Event Demo");
        setSize(400, 300);
        setLayout(new FlowLayout());

        textField = new TextField(20);
        add(textField);

        addMouseMotionListener(this);
        addMouseListener(this);

        setVisible(true);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                System.exit(0);
            }
        });
    }

    public void mouseMoved(MouseEvent e) {
        textField.setText("Mouse moved: X=" + e.getX() + " Y=" + e.getY());
    }

    public void mouseClicked(MouseEvent e) {
        textField.setText("Mouse clicked: X=" + e.getX() + " Y=" + e.getY());
    }

    // Unused methods from MouseListener and MouseMotionListener
    public void mouseDragged(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
    public void mousePressed(MouseEvent e) {}
    public void mouseReleased(MouseEvent e) {}

    public static void main(String[] args) {
        new slip_8_2();
    }
}

