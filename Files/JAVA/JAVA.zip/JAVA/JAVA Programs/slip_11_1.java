// Slip 11:
//Q1
// Define an interface “Operation” which has method volume( ).Define a constant PI having a value
// 3.142 Create a class cylinder which implements this interface (members – radius, height). Create
// one object and calculate the volume.

import java.util.Scanner;

interface Operation {
    double PI = 3.142; 
    double volume(); 
}

class slip_11_1 implements Operation {
    private double radius;
    private double height;

    public slip_11_1(double radius, double height) {
        this.radius = radius;
        this.height = height;
    }

    public double volume() {
        return PI * radius * radius * height;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter radius: ");
        double radius = scanner.nextDouble();
        System.out.print("Enter height: ");
        double height = scanner.nextDouble();

        slip_11_1 cylinder = new slip_11_1(radius, height);
        System.out.printf("Volume: %.2f\n", cylinder.volume());
    }
}

