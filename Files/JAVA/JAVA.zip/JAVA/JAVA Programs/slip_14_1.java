// Slip 14 :
// Q1
// Write a program to accept a number from the user, if number is zero then throw user defined
// exception “Number is 0” otherwise check whether no is prime or not (Use static keyword).

import java.util.Scanner;

class ZeroException extends Exception {
    public ZeroException(String message) {
        super(message);
    }
}

public class slip_14_1 {

    public static boolean isPrime(int number) {
        if (number < 2)
            return false;
        for (int i = 2; i <= Math.sqrt(number); i++) {
            if (number % i == 0)
                return false;
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int number = scanner.nextInt();

        try {
            if (number == 0) {
                throw new ZeroException("Number is 0");
            }

            String result = isPrime(number) ? "is a prime number." : "is not a prime number.";
            System.out.println(number + " " + result);

        } catch (ZeroException e) {
            System.out.println(e.getMessage());
        } finally {
            scanner.close();
        }
    }
}
