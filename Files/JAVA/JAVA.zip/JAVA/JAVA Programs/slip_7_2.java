// Slip 7:
//Q2
// Write a program to accept a text file from user and display the contents of a file in
// reverse order and change its case.

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class slip_7_2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the name of the text file (with extension): ");
        String fileName = scanner.nextLine();

        try {
            File file = new File(fileName);
            Scanner fileScanner = new Scanner(file);

            StringBuilder content = new StringBuilder();
            while (fileScanner.hasNextLine()) {
                content.append(fileScanner.nextLine()).append("\n");
            }
            fileScanner.close();

            String reversedContent = content.reverse().toString();
            String result = changeCase(reversedContent);

            System.out.println("Modified Content:\n" + result);

        } catch (FileNotFoundException e) {
            System.out.println("File not found. Please check the file name and path.");
        } finally {
            scanner.close();
        }
    }

    private static String changeCase(String str) {
        StringBuilder changedCase = new StringBuilder();
        for (char ch : str.toCharArray()) {
            if (Character.isLowerCase(ch)) {
                changedCase.append(Character.toUpperCase(ch));
            } else if (Character.isUpperCase(ch)) {
                changedCase.append(Character.toLowerCase(ch));
            } else {
                changedCase.append(ch);
            }
        }
        return changedCase.toString();
    }
}
