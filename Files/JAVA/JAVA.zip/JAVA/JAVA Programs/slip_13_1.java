// Slip 13:
// Q1
// Write a program to accept a file name from command prompt, if the file exits then display
// number of words and lines in that file.

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class slip_13_1 {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Usage: java SimpleFileCounter <filename>");
            return;
        }

        File file = new File(args[0]);

        if (!file.exists()) {
            System.out.println("File not found: " + args[0]);
            return;
        }

        int lines = 0;
        int words = 0;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines++;
                words += line.split("\\s+").length;
            }
        } catch (IOException e) {
            System.out.println("Error reading the file.");
        }

        System.out.println("Lines: " + lines);
        System.out.println("Words: " + words);
    }
}
