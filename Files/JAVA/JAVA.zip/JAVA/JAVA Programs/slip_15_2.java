// Slip 15
// Q2
// Write a program to define a class Account having members custname, accno. Define default
// and parameterized constructor. Create a subclass called SavingAccount with member savingbal,
// minbal. Create a derived class AccountDetail that extends the class SavingAccount with
// members, depositamt and withdrawalamt. Write a appropriate method to display customer
// details.

class Account {
    String custName;
    String accNo;

    public Account(String custName, String accNo) {
        this.custName = custName;
        this.accNo = accNo;
    }
}

class SavingAccount extends Account {
    double savingBal;

    public SavingAccount(String custName, String accNo, double savingBal) {
        super(custName, accNo);
        this.savingBal = savingBal;
    }
}

class AccountDetail extends SavingAccount {
    double depositAmt;
    double withdrawalAmt;

    public AccountDetail(String custName, String accNo, double savingBal, double depositAmt, double withdrawalAmt) {
        super(custName, accNo, savingBal);
        this.depositAmt = depositAmt;
        this.withdrawalAmt = withdrawalAmt;
    }

    public void displayDetails() {
        System.out.println("Customer Name: " + custName);
        System.out.println("Account Number: " + accNo);
        System.out.println("Saving Balance: " + savingBal);
        System.out.println("Deposit Amount: " + depositAmt);
        System.out.println("Withdrawal Amount: " + withdrawalAmt);
    }
}

public class slip_15_2 {
    public static void main(String[] args) {
        AccountDetail account = new AccountDetail("Alice", "123456", 5000.0, 1500.0, 300.0);

        account.displayDetails();
    }
}
