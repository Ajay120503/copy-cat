// Slip 4:
// Q2
// Write a program to design a screen using Awt that will take a user name and password. If
// the user name and password are not same, raise an Exception with appropriate message.
// User can have 3 login chances only. Use clear button to clear the TextFields.

import java.awt.*;
import java.awt.event.*;

public class slip_4_2 extends Frame implements ActionListener {
    private TextField usernameField;
    private TextField passwordField;
    private Label messageLabel;
    private Button loginButton;
    private Button clearButton;
    private int loginAttempts = 3; 

    public slip_4_2() {
        setTitle("Login Screen");
        setSize(300, 150);
        setLayout(new GridLayout(5, 2)); 

        Label usernameLabel = new Label("Username:");
        usernameField = new TextField(15);

        Label passwordLabel = new Label("Password:");
        passwordField = new TextField(15);
        passwordField.setEchoChar('*'); 

        messageLabel = new Label("");
        loginButton = new Button("Login");
        clearButton = new Button("Clear");

        add(usernameLabel);
        add(usernameField);
        add(passwordLabel);
        add(passwordField);
        add(loginButton);
        add(clearButton);
        add(messageLabel); 

        loginButton.addActionListener(this);
        clearButton.addActionListener(this);

        setVisible(true);
        setResizable(false);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                System.exit(0);
            }
        });
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginButton) {
            handleLogin();
        } else if (e.getSource() == clearButton) {
            clearFields();
        }
    }

    private void handleLogin() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        if (loginAttempts > 0) {
            if (username.equals(password)) {
                messageLabel.setText("Login Successful!");
                loginAttempts = 3;
            } else {
                loginAttempts--;
                messageLabel.setText("Incorrect! " + loginAttempts + " attempts left.");
                if (loginAttempts == 0) {
                    messageLabel.setText("No attempts left! Please clear to reset.");
                }
            }
        }
    }

    private void clearFields() {
        usernameField.setText("");
        passwordField.setText("");
        messageLabel.setText("");
        loginAttempts = 3; 
    }

    public static void main(String[] args) {
        new slip_4_2();
    }
}



