// Slip 15:
// Q1
// Accept the names of two files and copy the contents of the first to the second. First file having
// Book name and Author name in file.

import java.io.*;

public class slip_15_1 {
    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("Usage: java SimpleFileCopy <source file> <destination file>");
            return;
        }

        String sourceFileName = args[0];
        String destinationFileName = args[1];

        try (BufferedReader reader = new BufferedReader(new FileReader(sourceFileName));
            BufferedWriter writer = new BufferedWriter(new FileWriter(destinationFileName))) {

            String line;
            while ((line = reader.readLine()) != null) {
                writer.write(line);
                writer.newLine();
            }

            System.out.println("Contents copied from " + sourceFileName + " to " + destinationFileName);

        } catch (FileNotFoundException e) {
            System.out.println("Source file not found: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("Error during file operation: " + e.getMessage());
        }
    }
}
