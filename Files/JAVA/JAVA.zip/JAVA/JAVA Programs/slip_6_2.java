// Slip 6:
//Q2
// Create an abstract class “order” having members id, description. Create two subclasses
// “Purchase Order” and “Sales Order” having members customer name and Vendor name
// respectively. Define methods accept and display in all cases. Create 3 objects each of Purchase
// Order and Sales Order and accept and display details.

import java.util.Scanner;

abstract class Order {
    int id;
    String description;

    abstract void accept();
    abstract void display();
}

class PurchaseOrder extends Order {
    String customerName;

    void accept() {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Purchase Order ID: ");
        id = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter Description: ");
        description = sc.nextLine();

        System.out.print("Enter Customer Name: ");
        customerName = sc.nextLine();

    }

    void display() {
        System.out.println("Purchase Order: ID=" + id + ", Description=" + description + ", Customer=" + customerName);
    }
}

class SalesOrder extends Order {
    String vendorName;

    void accept() {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Sales Order ID: ");
        id = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter Description: ");
        description = sc.nextLine();
        
        System.out.print("Enter Vendor Name: ");
        vendorName = sc.nextLine();

    }

    void display() {
        System.out.println("Sales Order: ID=" + id + ", Description=" + description + ", Vendor=" + vendorName);
    }
}

public class slip_6_2 {
    public static void main(String[] args) {
        PurchaseOrder[] purchaseOrders = new PurchaseOrder[3];
        SalesOrder[] salesOrders = new SalesOrder[3];

        System.out.println("Enter Purchase Order details:");
        for (int i = 0; i < 3; i++) {
            purchaseOrders[i] = new PurchaseOrder();
            purchaseOrders[i].accept();
        }

        System.out.println("\nPurchase Orders:");
        for (PurchaseOrder po : purchaseOrders) {
            po.display();
        }

        System.out.println("\nEnter Sales Order details:");
        for (int i = 0; i < 3; i++) {
            salesOrders[i] = new SalesOrder();
            salesOrders[i].accept();
        }

        System.out.println("\nSales Orders:");
        for (SalesOrder so : salesOrders) {
            so.display();
        }
    }
}

