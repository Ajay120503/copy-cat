package student;

import java.util.Scanner;

public class StudentInfo {
    int rollNo;
    String name;
    String studentClass;
    public int[] marks = new int[6]; 

    public void acceptDetails() {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter Roll Number: ");
        rollNo = scanner.nextInt();
        scanner.nextLine(); 

        System.out.print("Enter Name: ");
        name = scanner.nextLine();

        System.out.print("Enter Class: ");
        studentClass = scanner.nextLine();

        System.out.println("Enter Marks for 6 subjects:");
        for (int i = 0; i < 6; i++) {
            System.out.print("Subject " + (i + 1) + ": ");
            marks[i] = scanner.nextInt();
        }
    }
}
