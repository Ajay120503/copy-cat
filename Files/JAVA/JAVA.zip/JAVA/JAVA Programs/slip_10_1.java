// Slip 10:
//Q1
// Write a program to find the cube of given number using functional interface.

interface CubeCalculator {
    int calculate(int number);
}

public class slip_10_1 {
    public static void main(String[] args) {
        CubeCalculator cube = number -> number * number * number;

        int number = 3; 
        int result = cube.calculate(number); 

        System.out.println("Cube of " + number + " is: " + result);
    }
}

