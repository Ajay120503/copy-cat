import java.awt.*;
import java.awt.event.*;

public class slip_16_2 {
    private Frame frame;
    private MenuBar menuBar;
    private TextArea textArea;

    public slip_16_2() {
        frame = new Frame("AWT Menu Bar Example");
        frame.setSize(400, 300);
        frame.setLayout(new BorderLayout());

        menuBar = new MenuBar();
        frame.setMenuBar(menuBar);

        Menu fileMenu = new Menu("File");
        MenuItem newItem = new MenuItem("New");
        MenuItem openItem = new MenuItem("Open");
        MenuItem saveItem = new MenuItem("Save");
        MenuItem lineItem = new MenuItem("Line");
        MenuItem exitItem = new MenuItem("Exit");

        fileMenu.add(newItem);
        fileMenu.add(openItem);
        fileMenu.add(saveItem);
        fileMenu.add(lineItem);
        fileMenu.addSeparator();
        fileMenu.add(exitItem);

        Menu editMenu = new Menu("Edit");

        Menu aboutMenu = new Menu("About");

        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        menuBar.add(aboutMenu);

        textArea = new TextArea();
        frame.add(textArea, BorderLayout.CENTER);

        newItem.addActionListener(e -> textArea.setText("New selected"));
        openItem.addActionListener(e -> textArea.setText("Open selected"));
        saveItem.addActionListener(e -> textArea.setText("Save selected"));
        lineItem.addActionListener(e -> textArea.setText("Line selected"));
        exitItem.addActionListener(e -> frame.dispose());

        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                frame.dispose();
            }
        });

        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new slip_16_2();
    }
}
