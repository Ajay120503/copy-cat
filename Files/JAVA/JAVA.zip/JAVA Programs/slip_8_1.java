// Slip 8:
//Q1
// Create a class Sphere, to calculate the volume and surface area of sphere.
// (Hint : Surface area=4*3.14(r*r), Volume=(4/3)3.14(r*r*r))

import java.util.Scanner;

class Sphere {
    private double radius;

    public Sphere(double radius) {
        this.radius = radius;
    }

    public double calculateSurfaceArea() {
        return 4 * Math.PI * (radius * radius);
    }

    public double calculateVolume() {
        return (4.0 / 3) * Math.PI * (radius * radius * radius);
    }
}

public class slip_8_1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the radius of the sphere: ");
        double radius = scanner.nextDouble();

        Sphere sphere = new Sphere(radius);

        double surfaceArea = sphere.calculateSurfaceArea();
        double volume = sphere.calculateVolume();

        System.out.printf("Surface Area of the Sphere: %.2f\n", surfaceArea);
        System.out.printf("Volume of the Sphere: %.2f\n", volume);

        scanner.close();
    }
}
