import java.awt.*;
import java.awt.event.*;

public class slip_18_1 {
    public static void main(String[] args) {
        // Create a frame
        Frame frame = new Frame("Border Layout Example");
        frame.setSize(400, 300);
        frame.setLayout(new BorderLayout());

        // Create components for each region
        Button btnNorth = new Button("North");
        Button btnSouth = new Button("South");
        Button btnEast = new Button("East");
        Button btnWest = new Button("West");
        Button btnCenter = new Button("Center");

        // Add components to the frame in the specified regions
        frame.add(btnNorth, BorderLayout.NORTH);
        frame.add(btnSouth, BorderLayout.SOUTH);
        frame.add(btnEast, BorderLayout.EAST);
        frame.add(btnWest, BorderLayout.WEST);
        frame.add(btnCenter, BorderLayout.CENTER);

        // Add a window listener to handle window closing
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                frame.dispose(); // Close the frame
            }
        });

        // Set the frame to be visible
        frame.setVisible(true);
    }
}

