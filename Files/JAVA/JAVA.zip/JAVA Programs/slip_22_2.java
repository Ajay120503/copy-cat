import java.awt.*;
import java.awt.event.*;

public class slip_22_2 {
    private Frame frame;
    private Label label;

    public slip_22_2() {
        // Create a frame
        frame = new Frame("Mouse Event Handler");
        frame.setSize(400, 300);
        frame.setLayout(new BorderLayout());

        // Create a label to display the event name
        label = new Label("Mouse Events", Label.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 24));
        label.setForeground(Color.RED); // Set text color to red
        frame.add(label, BorderLayout.CENTER);

        // Add mouse listener using an adapter class
        frame.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                label.setText("Mouse Clicked");
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                label.setText("Mouse Entered");
            }

            @Override
            public void mouseExited(MouseEvent e) {
                label.setText("Mouse Exited");
            }

            @Override
            public void mousePressed(MouseEvent e) {
                label.setText("Mouse Pressed");
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                label.setText("Mouse Released");
            }
        });

        // Add a window listener to close the application
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                frame.dispose(); // Close the frame
            }
        });

        // Set the frame to be visible
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new slip_22_2(); // Create an instance of the mouse event example
    }
}
