import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class slip_23_2 {
    private JFrame frame;
    private JTextField inputField;
    private JTextArea resultArea;
    private JComboBox<String> currencySelector;

    // Conversion rates
    private static final double USD_TO_SGD = 1.41;
    private static final double USD_TO_EURO = 0.92;
    private static final double SGD_TO_EURO = 0.65;

    public slip_23_2() {
        // Create the frame
        frame = new JFrame("Currency Converter");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        // Input field for amount
        inputField = new JTextField(10);
        frame.add(new JLabel("Enter Amount:"));
        frame.add(inputField);

        // Currency selection dropdown
        String[] currencies = {"SGD", "USD", "EUR"};
        currencySelector = new JComboBox<>(currencies);
        frame.add(currencySelector);

        // Convert button
        JButton convertButton = new JButton("Convert");
        frame.add(convertButton);

        // Text area for displaying results
        resultArea = new JTextArea(5, 30);
        resultArea.setEditable(false);
        frame.add(new JScrollPane(resultArea));

        // Button action
        convertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                convertCurrency();
            }
        });

        // Make the frame visible
        frame.setVisible(true);
    }

    private void convertCurrency() {
        try {
            // Get the amount entered by the user
            double amount = Double.parseDouble(inputField.getText());
            String selectedCurrency = (String) currencySelector.getSelectedItem();

            // Initialize conversion results
            double sgd = 0.0, usd = 0.0, euro = 0.0;

            // Perform conversion based on the selected currency
            switch (selectedCurrency) {
                case "SGD":
                    sgd = amount;
                    usd = sgd / USD_TO_SGD;
                    euro = sgd * SGD_TO_EURO;
                    break;
                case "USD":
                    usd = amount;
                    sgd = usd * USD_TO_SGD;
                    euro = usd * USD_TO_EURO;
                    break;
                case "EUR":
                    euro = amount;
                    usd = euro / USD_TO_EURO;
                    sgd = euro / SGD_TO_EURO;
                    break;
            }

            // Display the results formatted to two decimal places
            resultArea.setText(String.format("Converted Amounts:\n" +
                    "Singapore Dollars (SGD): %.2f\n" +
                    "US Dollars (USD): %.2f\n" +
                    "Euros (EUR): %.2f", sgd, usd, euro));
        } catch (NumberFormatException ex) {
            resultArea.setText("Please enter a valid number.");
        }
    }

    public static void main(String[] args) {
        new slip_23_2();
    }
}
