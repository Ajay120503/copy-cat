// Slip 1 :
// Q1
// Write a Program to print all Prime numbers in an array of n elements.
// (use command line arguments)

public class slip_1_1 {
    public static void main(String[] args) {

        int[] array = new int[args.length];

        for (int i = 0; i < args.length; i++) {
            array[i] = Integer.parseInt(args[i]);
        }

        System.out.println("Prime numbers in the given array:");
        for (int num : array) {

            if (num <= 1) {
                continue;
            }

            boolean isPrime = true;

            for (int i = 2; i * i <= num; i++) {
                if (num % i == 0) {
                    isPrime = false;
                    break;
                }
            }

            if (isPrime) {
                System.out.print(num);
            }
        }

    }
}
