import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class Student {
    private int rollno; // Student roll number
    private String name; // Student name
    private String studentClass; // Student class
    private float percentage; // Student percentage

    // Constructor
    public Student(int rollno, String name, String studentClass, float percentage) {
        this.rollno = rollno;
        this.name = name;
        this.studentClass = studentClass;
        this.percentage = percentage;
    }

    // Method to display student information
    public void displayInfo() {
        System.out.println("Roll No: " + rollno);
        System.out.println("Name: " + name);
        System.out.println("Class: " + studentClass);
        System.out.println("Percentage: " + percentage);
        System.out.println("-------------------------------");
    }
}

public class slip_25_1 {
    public static void main(String[] args) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.print("Enter the number of students: ");
            int numStudents = Integer.parseInt(reader.readLine()); // Read number of students

            // Array to hold student objects
            Student[] students = new Student[numStudents];

            // Loop to read student information
            for (int i = 0; i < numStudents; i++) {
                System.out.println("Enter details for Student " + (i + 1) + ":");

                System.out.print("Roll No: ");
                int rollno = Integer.parseInt(reader.readLine());

                System.out.print("Name: ");
                String name = reader.readLine();

                System.out.print("Class: ");
                String studentClass = reader.readLine();

                System.out.print("Percentage: ");
                float percentage = Float.parseFloat(reader.readLine());

                // Create a new Student object and store it in the array
                students[i] = new Student(rollno, name, studentClass, percentage);
                System.out.println(); // New line for better readability
            }

            // Display all student information
            System.out.println("Student Information:");
            for (Student student : students) {
                student.displayInfo();
            }

        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Please enter valid numbers for roll number and percentage.");
        }
    }
}
