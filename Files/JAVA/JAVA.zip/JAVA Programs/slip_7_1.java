// Slip 7:
//Q1
// Design a class for Bank. Bank Class should support following operations;
// a. Deposit a certain amount into an account
// b. Withdraw a certain amount from an account
// c. Return a Balance value specifying the amount with details

import java.util.Scanner;

class Bank {
    private double balance;
    Bank(double initialBalance) {
        balance = initialBalance;
    }

    void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited: $" + amount);
        } else {
            System.out.println("Invalid amount.");
        }
    }

    void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrew: $" + amount);
        } else {
            System.out.println("Invalid amount or insufficient balance.");
        }
    }

    double getBalance() {
        return balance;
    }
}

public class slip_7_1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter initial balance: ");
        double initialBalance = sc.nextDouble();
        Bank account = new Bank(initialBalance);

        while (true) {
            System.out.println("\n1. Deposit");
            System.out.println("2. Withdraw");
            System.out.println("3. Show Balance");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter amount to deposit: ");
                    account.deposit(sc.nextDouble());
                    break;
                case 2:
                    System.out.print("Enter amount to withdraw: ");
                    account.withdraw(sc.nextDouble());
                    break;
                case 3:
                    System.out.println("Current Balance: $" + account.getBalance());
                    break;
                case 4:
                    System.out.println("Exiting...");
                    sc.close();
                    return; 
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}

