// Slip 27:
// Q1
// Define an Employee class with suitable attributes having getSalary() method, which returns
// salary withdrawn by a particular employee. Write a class Manager which extends a class
// Employee, override the getSalary() method, which will return salary of manager by adding
// traveling allowance, house rent allowance etc.

// Employee class
// Employee class
class Employee {
    protected String name;  // Employee's name
    protected double salary; // Employee's base salary

    // Constructor to initialize name and salary
    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    // Method to get the base salary
    public double getSalary() {
        return salary;
    }
}

// Manager class that extends Employee
class Manager extends Employee {
    private double travelAllowance; // Additional travel allowance
    private double houseRentAllowance; // Additional house rent allowance

    // Constructor to initialize Manager's attributes
    public Manager(String name, double salary, double travelAllowance, double houseRentAllowance) {
        super(name, salary); // Call the constructor of Employee
        this.travelAllowance = travelAllowance;
        this.houseRentAllowance = houseRentAllowance;
    }

    // Override getSalary() to include allowances
    @Override
    public double getSalary() {
        // Return the total salary including allowances
        return salary + travelAllowance + houseRentAllowance;
    }
}

// Main class to test the program
public class Slip_27_1 {
    public static void main(String[] args) {
        // Create an Employee instance
        Employee employee = new Employee("Alice", 50000);
        System.out.println(employee.name + "'s Salary: " + employee.getSalary());

        // Create a Manager instance
        Manager manager = new Manager("Bob", 70000, 5000, 10000);
        System.out.println(manager.name + "'s Salary: " + manager.getSalary());
    }
}

