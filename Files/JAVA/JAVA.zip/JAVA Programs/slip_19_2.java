import java.awt.*;
import java.awt.event.*;

public class slip_19_2 {
    public static void main(String[] args) {
        Frame frame = new Frame("T.Y.B.Sc. (Comp. Sci) Subjects");
        frame.setSize(400, 200);
        frame.setLayout(new FlowLayout());

        Label label = new Label("Select Subject:");
        frame.add(label);

        String[] subjects = {
            "Data Structures",
            "Database Management Systems",
            "Operating Systems",
            "Software Engineering",
            "Computer Networks",
            "Web Technologies",
            "Java Programming"
        };
        
        final Choice subjectChoice = new Choice();

        for (String subject : subjects) {
            subjectChoice.add(subject);
        }
        frame.add(subjectChoice);

        TextField selectedSubjectField = new TextField(20);
        selectedSubjectField.setEditable(false); // Make it non-editable
        frame.add(selectedSubjectField);

        subjectChoice.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent ie) {
                selectedSubjectField.setText(subjectChoice.getSelectedItem());
            }
        });

        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                frame.dispose(); // Close the frame
            }
        });
        frame.setVisible(true);
    }
}
