// Slip 7:
//Q2
// Write a program to accept a text file from user and display the contents of a file in
// reverse order and change its case.

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class slip_7_2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the text file name: ");
        String fileName = scanner.nextLine();

        try {
            Scanner fileScanner = new Scanner(new File(fileName));
            StringBuilder content = new StringBuilder();

            while (fileScanner.hasNextLine()) {
                content.append(fileScanner.nextLine()).append("\n");
            }
            fileScanner.close();
            String reversedContent = new StringBuilder(content).reverse().toString();
            System.out.println("Modified Content:\n" + changeCase(reversedContent));

        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
        } finally {
            scanner.close();
        }
    }

    private static String changeCase(String str) {
        StringBuilder result = new StringBuilder();
        for (char ch : str.toCharArray()) {
            result.append(Character.isLowerCase(ch) ? Character.toUpperCase(ch) : Character.toLowerCase(ch));
        }
        return result.toString();
    }
}

