// Item class
class Item {
    private int itemNumber;    // Item number
    private String itemName;    // Item name
    private double itemPrice;    // Item price
    private static int itemCount = 0; // Static variable to count items

    // Parameterized constructor
    public Item(int itemNumber, String itemName, double itemPrice) {
        this.itemNumber = itemNumber;
        this.itemName = itemName;
        this.itemPrice = itemPrice;
        itemCount++; // Increment the item count
        System.out.println("Item created: " + itemName);
        System.out.println("Total items created: " + itemCount);
    }

    // Static method to get the count of items
    public static int getItemCount() {
        return itemCount;
    }

    // Method to display item details
    public void displayDetails() {
        System.out.println("Item Number: " + itemNumber);
        System.out.println("Item Name: " + itemName);
        System.out.println("Item Price: $" + itemPrice);
        System.out.println("---------------------------");
    }
}

// Main class to test the Item class
public class slip_26_1 {
    public static void main(String[] args) {
        // Create items using the parameterized constructor
        Item item1 = new Item(1, "Apple", 0.99);
        item1.displayDetails();

        Item item2 = new Item(2, "Banana", 0.59);
        item2.displayDetails();

        Item item3 = new Item(3, "Cherry", 2.99);
        item3.displayDetails();
    }
}
