// Slip 5:
//Q2
// Write a menu driven program to perform the following operations on multidimensional array
// ie matrices :
// - Addition
// - Multiplication
// - Exit

import java.util.Scanner;

public class slip_5_2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the size of matrices (rows and columns): ");
        int size = sc.nextInt();

        int[][] matrix1 = new int[size][size];
        int[][] matrix2 = new int[size][size];

        System.out.println("Enter elements of Matrix 1:");
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                matrix1[i][j] = sc.nextInt();
            }
        }

        System.out.println("Enter elements of Matrix 2:");
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                matrix2[i][j] = sc.nextInt();
            }
        }

        int choice;
        do {
            System.out.println("\nMenu:");
            System.out.println("1. Matrix Addition");
            System.out.println("2. Matrix Multiplication");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Result of Matrix Addition:");
                    for (int i = 0; i < size; i++) {
                        for (int j = 0; j < size; j++) {
                            System.out.print((matrix1[i][j] + matrix2[i][j]) + " ");
                        }
                        System.out.println();
                    }
                    break;

                case 2:
                    System.out.println("Result of Matrix Multiplication:");
                    int[][] product = new int[size][size];
                    for (int i = 0; i < size; i++) {
                        for (int j = 0; j < size; j++) {
                            product[i][j] = 0;
                            for (int k = 0; k < size; k++) {
                                product[i][j] += matrix1[i][k] * matrix2[k][j];
                            }
                            System.out.print(product[i][j] + " ");
                        }
                        System.out.println();
                    }
                    break;

                case 3:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        } while (choice != 3);

        sc.close();
    }
}
