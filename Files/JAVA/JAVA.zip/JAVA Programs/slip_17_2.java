import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class slip_17_2 {

    // Declare GUI components
    private JFrame frame;
    private JTextField textField1, textField2, resultField;
    private JButton concatButton, reverseButton;

    public slip_17_2() {
        // Initialize the frame
        frame = new JFrame("String Manipulator");
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        // Text fields
        textField1 = new JTextField(10);
        textField2 = new JTextField(10);
        resultField = new JTextField(10);
        resultField.setEditable(false);

        // Buttons
        concatButton = new JButton("Concatenate");
        reverseButton = new JButton("Reverse");

        // Add components to frame
        frame.add(new JLabel("Text 1:"));
        frame.add(textField1);
        frame.add(new JLabel("Text 2:"));
        frame.add(textField2);
        frame.add(new JLabel("Result:"));
        frame.add(resultField);
        frame.add(concatButton);
        frame.add(reverseButton);

        // Action listener for concatenation button
        concatButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Concatenate text from textField1 and textField2
                String result = textField1.getText() + textField2.getText();
                resultField.setText(result);
            }
        });

        // Action listener for reverse button
        reverseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Reverse text from textField1
                String input = textField1.getText();
                String result = new StringBuilder(input).reverse().toString();
                resultField.setText(result);
            }
        });

        // Make frame visible
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new slip_17_2();
    }
}
