// Slip 4:
//Q1
// Write a program to print an array after changing the rows and columns of a given two-dimensional array.

public class slip_4_1 {
    public static void main(String[] args) {
        int[][] original = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
        };

        int rows = original.length;
        int cols = original[0].length;

        int[][] transposed = new int[cols][rows];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                transposed[j][i] = original[i][j];
            }
        }

        System.out.println("Original Array:");
        printArray(original);

        System.out.println("Transposed Array:");
        printArray(transposed);
    }

    public static void printArray(int[][] array) {
        for (int[] row : array) {
            for (int value : row) {
                System.out.print(value + " ");
            }
            System.out.println();
        }
    }
}
