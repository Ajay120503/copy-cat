public class slip_23_1 {
    private int data; // Private data member

    // Default constructor
    public slip_23_1() {
        this.data = 0; // Initialize to 0
    }

    // Parameterized constructor using 'this'
    public slip_23_1(int value) {
        this.data = value; // Initialize with the provided value
    }

    // Method to check if the number is negative
    public boolean isNegative() {
        return data < 0;
    }

    // Method to check if the number is positive
    public boolean isPositive() {
        return data > 0;
    }

    // Method to check if the number is zero
    public boolean isZero() {
        return data == 0;
    }

    // Method to check if the number is odd
    public boolean isOdd() {
        return data % 2 != 0;
    }

    // Method to check if the number is even
    public boolean isEven() {
        return data % 2 == 0;
    }

    // Main method to test the MyNumber class
    public static void main(String[] args) {
        // Check if a command line argument is provided
        if (args.length > 0) {
            try {
                // Parse the command line argument to an integer
                int value = Integer.parseInt(args[0]);
                slip_23_1 myNumber = new slip_23_1(value); // Create MyNumber object

                // Display results
                System.out.println("Number: " + value);
                System.out.println("Is Negative: " + myNumber.isNegative());
                System.out.println("Is Positive: " + myNumber.isPositive());
                System.out.println("Is Zero: " + myNumber.isZero());
                System.out.println("Is Odd: " + myNumber.isOdd());
                System.out.println("Is Even: " + myNumber.isEven());
            } catch (NumberFormatException e) {
                System.out.println("Please provide a valid integer.");
            }
        } else {
            System.out.println("Please provide a number as a command line argument.");
        }
    }
}
