// Slip 29:
// Q2
// Write a program to create a super class Vehicle having members Company and price.
// Derive two different classes LightMotorVehicle(mileage) and HeavyMotorVehicle
// (capacity_in_tons). Accept the information for "n" vehicles and display the information in
// appropriate form. While taking data, ask user about the type of vehicle first.

import java.util.Scanner;

// Superclass Vehicle
class Vehicle {
    String company;
    double price;

    // Constructor for common properties
    public Vehicle(String company, double price) {
        this.company = company;
        this.price = price;
    }

    // Method to display common details
    public void displayDetails() {
        System.out.println("Company: " + company);
        System.out.println("Price: " + price);
    }
}

// LightMotorVehicle class
class LightMotorVehicle extends Vehicle {
    double mileage;

    public LightMotorVehicle(String company, double price, double mileage) {
        super(company, price);
        this.mileage = mileage;
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Mileage: " + mileage + " km/l");
    }
}

// HeavyMotorVehicle class
class HeavyMotorVehicle extends Vehicle {
    double capacity_in_tons;

    public HeavyMotorVehicle(String company, double price, double capacity_in_tons) {
        super(company, price);
        this.capacity_in_tons = capacity_in_tons;
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Capacity: " + capacity_in_tons + " tons");
    }
}

public class slip_29_2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of vehicles: ");
        int n = scanner.nextInt();
        Vehicle[] vehicles = new Vehicle[n];

        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details for vehicle " + (i + 1) + ":");
            System.out.print("Enter type of vehicle (1 for Light, 2 for Heavy): ");
            int type = scanner.nextInt();

            scanner.nextLine();  // Consume newline
            System.out.print("Enter company: ");
            String company = scanner.nextLine();
            System.out.print("Enter price: ");
            double price = scanner.nextDouble();

            switch (type) {
                case 1:
                    System.out.print("Enter mileage: ");
                    double mileage = scanner.nextDouble();
                    vehicles[i] = new LightMotorVehicle(company, price, mileage);
                    break;
                case 2:
                    System.out.print("Enter capacity (in tons): ");
                    double capacity = scanner.nextDouble();
                    vehicles[i] = new HeavyMotorVehicle(company, price, capacity);
                    break;
                default:
                    System.out.println("Invalid vehicle type.");
                    i--;  // Repeat the iteration for invalid input
                    break;
            }
        }

        // Display vehicle information
        System.out.println("\nVehicle Information:");
        for (Vehicle vehicle : vehicles) {
            vehicle.displayDetails();
            System.out.println();  // Blank line between vehicle details
        }

        scanner.close();
    }
}
