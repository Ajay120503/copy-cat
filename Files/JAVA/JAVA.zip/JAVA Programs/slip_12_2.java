// Slip 12:
// Q2
// Write a java program that works as a simple calculator. Use a grid layout to arrange buttons for
// the digits and for the +, -, *, % operations. Add a text field to display the result.

import java.awt.*;
import java.awt.event.*;

public class slip_12_2 extends Frame implements ActionListener {
    private TextField displayField;
    private double firstOperand = 0;
    private String operator = "";

    public slip_12_2() {
        setTitle("Simple Calculator");
        setSize(300, 400);
        setLayout(new BorderLayout());

        displayField = new TextField();
        displayField.setEditable(false);
        displayField.setFont(new Font("Arial", Font.BOLD, 24));
        add(displayField, BorderLayout.NORTH);

        Panel buttonPanel = new Panel();
        buttonPanel.setLayout(new GridLayout(4, 4));

        String[] buttons = {
                "7", "8", "9", "/",
                "4", "5", "6", "*",
                "1", "2", "3", "-",
                "C", "0", "=", "+"
        };

        for (String text : buttons) {
            Button button = new Button(text);
            button.addActionListener(this);
            buttonPanel.add(button);
        }

        add(buttonPanel, BorderLayout.CENTER);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                System.exit(0);
            }
        });
    }

    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();

        switch (command) {
            case "C":
                displayField.setText("");
                operator = "";
                firstOperand = 0;
                break;

            case "=":
                double secondOperand = Double.parseDouble(displayField.getText());
                double result = calculate(firstOperand, secondOperand, operator);
                displayField.setText(String.valueOf(result));
                operator = "";
                break;

            default:
                if (isOperator(command)) {
                    firstOperand = Double.parseDouble(displayField.getText());
                    operator = command;
                    displayField.setText("");
                } else {
                    displayField.setText(displayField.getText() + command);
                }
                break;
        }
    }

    private boolean isOperator(String command) {
        return command.equals("+") || command.equals("-") || command.equals("*") || command.equals("/");
    }

    private double calculate(double first, double second, String op) {
        switch (op) {
            case "+":
                return first + second;
            case "-":
                return first - second;
            case "*":
                return first * second;
            case "/":
                return second != 0 ? first / second : 0;
            default:
                return 0;
        }
    }

    public static void main(String[] args) {
        slip_12_2 calculator = new slip_12_2();
        calculator.setVisible(true);
    }
}
