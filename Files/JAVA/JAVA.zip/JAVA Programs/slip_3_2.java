// Slip 3:
//Q2
// Define a class patient (patient_name, patient_age, patient_oxy_level,patient_HRCT_report).
// Create an object of patient. Handle appropriate exception while patient oxygen level less than
// 95% and HRCT scan report greater than 10, then throw user defined Exception “Patient is Covid
// Positive(+) and Need to Hospitalized” otherwise display its information.

class CovidPositiveException extends Exception {
    public CovidPositiveException(String message) {
        super(message);
    }
}

class Patient {
    String name;
    int age;
    double oxyLevel;
    int hrctReport;

    public Patient(String name, int age, double oxyLevel, int hrctReport) {
        this.name = name;
        this.age = age;
        this.oxyLevel = oxyLevel;
        this.hrctReport = hrctReport;
    }

    public void checkStatus() throws CovidPositiveException {
        if (oxyLevel < 95 || hrctReport > 10) {
            throw new CovidPositiveException("Patient is Covid Positive(+) and Needs to be Hospitalized");
        }
        else{
            System.out.println("Patient is Healthy");
        }
    }

    public void displayInfo() {
        System.out.println("Patient Name: " + name);
        System.out.println("Patient Age: " + age);
        System.out.println("Oxygen Level: " + oxyLevel + "%");
        System.out.println("HRCT Report Score: " + hrctReport);
    }
}

public class slip_3_2 {
    public static void main(String[] args) {
        Patient patient = new Patient("Sohan", 30, 96, 10);

        try {
            patient.checkStatus();
        } catch (CovidPositiveException e) {
            System.out.println(e.getMessage());
        }

        patient.displayInfo();
    }
}
