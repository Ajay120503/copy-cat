// Slip 5:
// Q1
// Write a program for multilevel inheritance such that Country is inherited from Continent.
// State is inherited from Country. Display the place, State, Country and Continent.

class Continent {
    String continentName;

    Continent(String continentName) {
        this.continentName = continentName;
    }
}

class Country extends Continent {
    String countryName;

    Country(String continentName, String countryName) {
        super(continentName);
        this.countryName = countryName;
    }
}

class State extends Country {
    String stateName;

    State(String continentName, String countryName, String stateName) {
        super(continentName, countryName);
        this.stateName = stateName;
    }

    public void displayDetails() {
        System.out.println("State: " + stateName);
        System.out.println("Country: " + countryName);
        System.out.println("Continent: " + continentName);
    }
}

public class slip_5_1 {
    public static void main(String[] args) {
        State myState = new State("Asia", "India", "Karnataka");

        myState.displayDetails();
    }
}
