// Slip 9:
//Q1
// Define a “Clock” class that does the following ;
// a. Accept Hours, Minutes and Seconds
// b. Check the validity of numbers
// c. Set the time to AM/PM mode
// Use the necessary constructors and methods to do the above task
// import java.util.Set;

import java.util.Scanner;

class Clock {
    private int hours;
    private int minutes;
    private int seconds;

    public Clock(int hours, int minutes, int seconds) {
        if (isValidTime(hours, minutes, seconds)) {
            this.hours = hours;
            this.minutes = minutes;
            this.seconds = seconds;
        } else {
            System.out.println("Invalid time provided. Setting to default (12:00:00 AM).");
            this.hours = 12;
            this.minutes = 0;
            this.seconds = 0;
        }
    }

    private boolean isValidTime(int hours, int minutes, int seconds) {
        return (hours >= 0 && hours < 24) && (minutes >= 0 && minutes < 60) && (seconds >= 0 && seconds < 60);
    }

    public void displayTime() {
        String period = (hours >= 12) ? "PM" : "AM";
        int displayHours = (hours % 12 == 0) ? 12 : hours % 12;
        System.out.printf("Current Time: %02d:%02d:%02d %s%n", displayHours, minutes, seconds, period);
    }
}

public class slip_9_1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter hours (0-23): ");
        int hours = scanner.nextInt();
        System.out.print("Enter minutes (0-59): ");
        int minutes = scanner.nextInt();
        System.out.print("Enter seconds (0-59): ");
        int seconds = scanner.nextInt();

        Clock clock = new Clock(hours, minutes, seconds);
        clock.displayTime();

        scanner.close();
    }
}
