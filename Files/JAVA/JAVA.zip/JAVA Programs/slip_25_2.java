import java.awt.*;
import java.awt.event.*;

class slip_25_2 {
    private Frame frame;
    private TextField nameField;
    private CheckboxGroup classGroup;
    private Checkbox SY, FY, TY;
    private Checkbox hobby1, hobby2, hobby3;
    private Label label;
    private Button submitButton;
    private TextArea outputArea;

    public slip_25_2() {
        frame = new Frame("GUI");
        frame.setSize(400, 350);
        frame.setLayout(null);

        label = new Label("Enter the Name : ");
        label.setBounds(10, 50, 100, 30);
        frame.add(label);

        nameField = new TextField();
        nameField.setBounds(120, 50, 160, 30);
        frame.add(nameField);

        label = new Label("Choice your class");
        label.setBounds(10, 80, 100, 30);
        frame.add(label);

        classGroup = new CheckboxGroup();
        FY = new Checkbox("FY", classGroup, false);
        SY = new Checkbox("SY", classGroup, false);
        TY = new Checkbox("TY", classGroup, false);

        FY.setBounds(10, 110, 50, 30);
        SY.setBounds(10, 140, 50, 30);
        TY.setBounds(10, 170, 50, 30);

        frame.add(FY);
        frame.add(SY);
        frame.add(TY);

        label = new Label("Choice your Hobbies");
        label.setBounds(150, 80, 120, 30);
        frame.add(label);

        hobby1 = new Checkbox("Music");
        hobby2 = new Checkbox("Dance");
        hobby3 = new Checkbox("Sport");

        hobby1.setBounds(150, 110, 100, 30);
        hobby2.setBounds(150, 140, 100, 30);
        hobby3.setBounds(150, 170, 100, 30);

        frame.add(hobby1);
        frame.add(hobby2);
        frame.add(hobby3);

        submitButton = new Button("Display the Result");
        submitButton.setBounds(100, 200, 150, 30);
        frame.add(submitButton);

        outputArea = new TextArea();
        outputArea.setBounds(10, 250, 360, 100);
        outputArea.setEditable(false);
        frame.add(outputArea);

        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                display();
            }
        });

        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                frame.dispose();
            }
        });
        frame.setVisible(true);
    }

    private void display() {
        // Get the input values
        String name = nameField.getText();
        String selectedClass = classGroup.getSelectedCheckbox() != null ? classGroup.getSelectedCheckbox().getLabel()
                : "None";

        StringBuilder hobbies = new StringBuilder();
        if (hobby1.getState())
            hobbies.append(hobby1.getLabel()).append(", ");
        if (hobby2.getState())
            hobbies.append(hobby2.getLabel()).append(", ");
        if (hobby3.getState())
            hobbies.append(hobby3.getLabel()).append(", ");

        if (hobbies.length() > 0) {
            hobbies.setLength(hobbies.length() - 2); // Remove the last comma
        } else {
            hobbies.append("None");
        }

        outputArea.setText("Name: " + name + "\nClass: " + selectedClass + "\nHobbies: " + hobbies);
    }

    public static void main(String[] args) {
        new slip_25_2();
    }
}