import java.io.*;
import java.util.*;
import java.text.*;

class Donor implements Serializable {
    String name;
    int age;
    String address;
    String contactNumber;
    String bloodGroup;
    String lastDonationDate; // Use String for simplicity

    // Constructor
    public Donor(String name, int age, String address, String contactNumber, String bloodGroup, String lastDonationDate) {
        this.name = name;
        this.age = age;
        this.address = address;
        this.contactNumber = contactNumber;
        this.bloodGroup = bloodGroup;
        this.lastDonationDate = lastDonationDate;
    }

    // Method to display donor details
    public void displayDetails() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Address: " + address);
        System.out.println("Contact Number: " + contactNumber);
        System.out.println("Blood Group: " + bloodGroup);
        System.out.println("Last Donation Date: " + lastDonationDate);
        System.out.println("-------------------------------");
    }
}

public class slip_26_2 {
    private static final String FILE_NAME = "donors.dat";

    // Method to write donors to a file
    public static void writeDonors(List<Donor> donors) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(donors);
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }

    // Method to read donors from a file
    @SuppressWarnings("unchecked")
    public static List<Donor> readDonors() {
        List<Donor> donors = null;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            donors = (List<Donor>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error reading from file: " + e.getMessage());
        }
        return donors;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Donor> donors = new ArrayList<>();

        // Input donors' details
        System.out.print("Enter the number of donors: ");
        int n = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        for (int i = 0; i < n; i++) {
            System.out.println("Donor " + (i + 1) + ":");
            System.out.print("Name: ");
            String name = scanner.nextLine();
            System.out.print("Age: ");
            int age = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Address: ");
            String address = scanner.nextLine();
            System.out.print("Contact Number: ");
            String contactNumber = scanner.nextLine();
            System.out.print("Blood Group: ");
            String bloodGroup = scanner.nextLine();
            System.out.print("Last Donation Date (yyyy-MM-dd): ");
            String lastDonationDate = scanner.nextLine();
            donors.add(new Donor(name, age, address, contactNumber, bloodGroup, lastDonationDate));
            System.out.println();
        }

        // Write donors to file
        writeDonors(donors);
        System.out.println("Donors have been written to the file.");

        // Read donors from file
        List<Donor> readDonors = readDonors();
        System.out.println("Donors with blood group 'A+ve' and not donated in the last 6 months:");

        // Filtering logic for donors who haven't donated in the last 6 months
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, -6);
        String sixMonthsAgo = new SimpleDateFormat("yyyy-MM-dd").format(calendar.getTime());

        for (Donor donor : readDonors) {
            if ("A+ve".equals(donor.bloodGroup) && donor.lastDonationDate.compareTo(sixMonthsAgo) < 0) {
                donor.displayDetails();
            }
        }
    }
}
