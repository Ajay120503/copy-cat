// Slip 2:
// Q2
// Define a class CricketPlayer (name,no_of_innings,no_of_times_notout, totatruns, bat_avg).
// Create an array of n player objects .Calculate the batting average for each player using static
// method avg(). Define a static sort method which sorts the array on the basis of average. Display
// the player details in sorted order.

import java.util.Scanner;
import java.util.Arrays;

class CricketPlayer {
    String name;
    int no_of_innings;
    int no_of_times_notout;
    int total_runs;
    double bat_avg;

    public CricketPlayer(String name, int no_of_innings, int no_of_times_notout, int total_runs) {
        this.name = name;
        this.no_of_innings = no_of_innings;
        this.no_of_times_notout = no_of_times_notout;
        this.total_runs = total_runs;
        this.bat_avg = 0;
    }

    public static void avg(CricketPlayer player) {
        if (player.no_of_innings - player.no_of_times_notout > 0) {
            player.bat_avg = (double) player.total_runs / (player.no_of_innings - player.no_of_times_notout);
        } else {
            player.bat_avg = player.total_runs; 
        }
    }

    public static void sort(CricketPlayer[] players) {
        Arrays.sort(players, (p1, p2) -> Double.compare(p1.bat_avg, p2.bat_avg));
    }

    public void display() {
        System.out.println("Name: " + name + ", Innings: " + no_of_innings + ", Not Out: " + no_of_times_notout +
                ", Total Runs: " + total_runs + ", Batting Average: " + bat_avg);
    }
}

public class slip_2_2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of players: ");
        int n = scanner.nextInt();
        scanner.nextLine();

        CricketPlayer[] players = new CricketPlayer[n];

        for (int i = 0; i < n; i++) {

            System.out.print("Name: ");
            String name = scanner.nextLine();

            System.out.print("Number of Innings: ");
            int no_of_innings = scanner.nextInt();

            System.out.print("Number of Times Not Out: ");
            int no_of_times_notout = scanner.nextInt();

            System.out.print("Total Runs: ");
            int total_runs = scanner.nextInt();
            scanner.nextLine();

            players[i] = new CricketPlayer(name, no_of_innings, no_of_times_notout, total_runs);
        }

        for (CricketPlayer player : players) {
            CricketPlayer.avg(player);
        }

        CricketPlayer.sort(players);

        System.out.println("\nPlayer details sorted by batting average:");
        for (CricketPlayer player : players) {
            player.display();
        }

        scanner.close();
    }
}
