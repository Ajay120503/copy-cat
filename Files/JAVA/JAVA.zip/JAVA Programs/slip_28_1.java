// Slip 28:
// Q1
// Write a program that reads on file name from the user, then displays information about
// whether the file exists, whether the file is readable, whether the file is writable, the type of
// file and the length of the file in bytes.

import java.io.File;
import java.util.Scanner;

public class slip_28_1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get file name from user
        System.out.print("Enter the file name: ");
        String fileName = scanner.nextLine();
        
        System.out.print("file name: "+fileName);

        // Create File object
        File file = new File(fileName);

        // Display file information
        if (file.exists()) {
            System.out.println("File exists: Yes");
            System.out.println("Readable: " + file.canRead());
            System.out.println("Writable: " + file.canWrite());
            System.out.println("File type: " + (file.isDirectory() ? "Directory" : "File"));
            System.out.println("File length (bytes): " + file.length());
        } else {
            System.out.println("File does not exist.");
        }

        scanner.close();
    }
}

