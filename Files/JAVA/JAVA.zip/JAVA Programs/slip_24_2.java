import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class slip_24_2 extends JPanel {
    private final ArrayList<Point> circleCenters; // List to store the centers of the circles

    // Constructor
    public slip_24_2() {
        circleCenters = new ArrayList<>(); // Initialize the list
        // Mouse listener to handle mouse clicks
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Store the click position
                circleCenters.add(e.getPoint());
                repaint(); // Repaint the panel to display circles
            }
        });
    }

    // Override paintComponent to draw the circles
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); // Call the superclass method to clear the panel
        g.setColor(Color.BLUE); // Set color for the circles

        for (Point center : circleCenters) {
            int radius1 = 20; // Radius of the first circle
            int radius2 = 40; // Radius of the second circle
            int radius3 = 60; // Radius of the third circle

            // Draw concentric circles
            g.drawOval(center.x - radius3, center.y - radius3, 2 * radius3, 2 * radius3); // Largest circle
            g.drawOval(center.x - radius2, center.y - radius2, 2 * radius2, 2 * radius2); // Middle circle
            g.drawOval(center.x - radius1, center.y - radius1, 2 * radius1, 2 * radius1); // Smallest circle
        }
    }

    // Main method to run the program
    public static void main(String[] args) {
        JFrame frame = new JFrame("Concentric Circles"); // Create a new frame
        slip_24_2 panel = new slip_24_2(); // Create an instance of ConcentricCircles

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Set default close operation
        frame.add(panel); // Add the panel to the frame
        frame.setSize(800, 600); // Set the size of the frame
        frame.setVisible(true); // Make the frame visible
    }
}
