// Slip 27:
// Q1
// Write a program to accept a string as command line argument and check whether it is a file or
// directory. Also perform operations as follows:
// i)If it is a directory,delete all text files in that directory. Confirm delete operation from
// user before deleting text files. Also, display a count showing the number of files deleted,
// if any, from the directory.
// ii)If it is a file display various details of that file.

import java.io.File;
import java.util.Scanner;

public class slip_27_2 {
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java FileDirectoryHandler <path>");
            return;
        }

        String path = args[0];
        File file = new File(path);

        // Check if the path exists
        if (!file.exists()) {
            System.out.println("The specified path does not exist.");
            return;
        }

        // Determine if it's a file or directory using a switch
        String type = file.isDirectory() ? "directory" : file.isFile() ? "file" : "unknown";

        switch (type) {
            case "directory":
                System.out.println("It is a directory.");
                File[] textFiles = file.listFiles((dir, name) -> name.endsWith(".txt"));
                
                if (textFiles == null || textFiles.length == 0) {
                    System.out.println("No text files found in the directory.");
                    return;
                }

                System.out.println("Text files found: " + textFiles.length);
                System.out.print("Delete all text files? (yes/no): ");
                
                Scanner scanner = new Scanner(System.in);
                String confirmation = scanner.nextLine();

                if (confirmation.equalsIgnoreCase("yes")) {
                    int deletedCount = 0;
                    for (File txtFile : textFiles) {
                        if (txtFile.delete()) deletedCount++;
                    }
                    System.out.println(deletedCount + " text file(s) deleted.");
                } else {
                    System.out.println("Operation canceled.");
                }
                break;

            case "file":
                System.out.println("It is a file.");
                System.out.println("Name: " + file.getName());
                System.out.println("Size: " + file.length() + " bytes");
                System.out.println("Readable: " + file.canRead());
                System.out.println("Writable: " + file.canWrite());
                break;

            default:
                System.out.println("Unknown file type.");
                break;
        }
    }
}

