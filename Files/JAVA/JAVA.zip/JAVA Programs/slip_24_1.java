// Abstract class Bank
abstract class Bank {
    // Abstract method to get balance
    abstract int getBalance();
}

// BankA class extending Bank
class BankA extends Bank {
    private int balance = 100; // Deposited amount

    @Override
    int getBalance() {
        return balance;
    }
}

// BankB class extending Bank
class BankB extends Bank {
    private int balance = 150; // Deposited amount

    @Override
    int getBalance() {
        return balance;
    }
}

// BankC class extending Bank
class BankC extends Bank {
    private int balance = 200; // Deposited amount

    @Override
    int getBalance() {
        return balance;
    }
}

// Main class to test the implementation
public class slip_24_1 {
    public static void main(String[] args) {
        // Create objects for each bank
        Bank bankA = new BankA();
        Bank bankB = new BankB();
        Bank bankC = new BankC();

        // Call getBalance method and display the balance
        System.out.println("Balance in Bank A: Rs." + bankA.getBalance());
        System.out.println("Balance in Bank B: Rs." + bankB.getBalance());
        System.out.println("Balance in Bank C: Rs." + bankC.getBalance());
    }
}
