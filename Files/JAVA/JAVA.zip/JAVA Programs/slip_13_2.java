// Slip 13:
// Q2
// Write a program to display the system date and time in various formats shown below:
// Current date is : 31/08/2021
// Current date is : 08-31-2021
// Current date is : Tuesday August 31 2021
// Current date and time is : Fri August 31 15:25:59 IST 2021
// Current date and time is : 31/08/21 15:25:59 PM +0530

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;

public class slip_13_2 {
    public static void main(String[] args) {
        LocalDateTime now = LocalDateTime.now(ZoneId.of("Asia/Kolkata"));

        DateTimeFormatter format1 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DateTimeFormatter format2 = DateTimeFormatter.ofPattern("MM-dd-yyyy");
        DateTimeFormatter format3 = DateTimeFormatter.ofPattern("EEEE MMMM dd yyyy");
        DateTimeFormatter format4 = DateTimeFormatter.ofPattern("EEEE MMMM dd HH:mm:ss zzz yyyy");
        DateTimeFormatter format5 = DateTimeFormatter.ofPattern("dd/MM/yy HH:mm:ss a Z");

        System.out.println("Current date is : " + now.format(format1));
        System.out.println("Current date is : " + now.format(format2));
        System.out.println("Current date is : " + now.format(format3));
        System.out.println("Current date and time is : " + now.format(format4));
        System.out.println("Current date and time is : " + now.format(format5));
    }
}
