// Slip 11:
//Q2
// Write a program to accept the username and password from user if username and password are
// not same then raise "Invalid Password" with appropriate msg.

import java.util.Scanner;

class InvalidPasswordException extends Exception {
    public InvalidPasswordException(String message) {
        super(message);
    }
}

public class slip_11_2 {
    @SuppressWarnings("resource")
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        try {
            if (!username.equals(password)) {
                throw new InvalidPasswordException("Invalid Password: Username and Password do not match!");
            } else {
                System.out.println("Login Successful!");
            }
        } catch (InvalidPasswordException e) {
            System.out.println(e.getMessage());
        }

        scanner.close();
    }
}

