// Slip 6:
//Q1
// Write a program to display the Employee(Empid, Empname, Empdesignation, Empsal)
// information using toString().

class Employee {
    int empId;
    String empName;
    String empDesignation;
    double empSalary;

    public Employee(int id, String name, String designation, double salary) {
        empId = id;
        empName = name;
        empDesignation = designation;
        empSalary = salary;
    }

    public String toString() {
        return "ID: " + empId + ", Name: " + empName + ", Designation: " + empDesignation + ", Salary: $" + empSalary;
    }
}

public class slip_6_1 {
    public static void main(String[] args) {
        Employee emp = new Employee(1, "Samarth", "Manager", 500.00);

        System.out.println(emp);
    }
}


