// Slip 29:
// Q1
// Write a program to create a class Customer(custno,custname,contactnumber,custaddr).
// Write a method to search the customer name with given contact number and display the
// details.

import java.util.Scanner;
class Customer {
    int custno;
    String custname;
    String contactnumber;
    String custaddr;

    public Customer(int custno, String custname, String contactnumber, String custaddr) {
        this.custno = custno;
        this.custname = custname;
        this.contactnumber = contactnumber;
        this.custaddr = custaddr;
    }

    public void displayCustomerDetails() {
        System.out.println("Customer Number: " + custno);
        System.out.println("Customer Name: " + custname);
        System.out.println("Contact Number: " + contactnumber);
        System.out.println("Customer Address: " + custaddr);
    }
}

public class slip_29_1 {
    public static void main(String[] args) {
        Customer[] customers = {
            new Customer(1, "John Doe", "1234567890", "123 Main St"),
            new Customer(2, "Jane Smith", "9876543210", "456 Maple Ave"),
            new Customer(3, "Alice Johnson", "5555555555", "789 Oak Dr")
        };
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter contact number to search for customer: ");
        String searchContact = scanner.nextLine();

        boolean found = false;
        for (Customer customer : customers) {
            if (customer.contactnumber.equals(searchContact)) {
                System.out.println("Customer found!");
                customer.displayCustomerDetails();
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Customer with contact number " + searchContact + " not found.");
        }

        scanner.close();
    }
}
