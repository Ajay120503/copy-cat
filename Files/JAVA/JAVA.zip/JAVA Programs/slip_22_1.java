// Abstract class Shape
abstract class Shape {
    protected int dimension1; // For length or base
    protected int dimension2; // For breadth or height

    // Constructor to initialize dimensions
    public Shape(int dimension1, int dimension2) {
        this.dimension1 = dimension1;
        this.dimension2 = dimension2;
    }

    // Abstract method to print area
    abstract void printArea();
}

// Class for Rectangle
class Rectangle extends Shape {
    // Constructor
    public Rectangle(int length, int breadth) {
        super(length, breadth);
    }

    // Override printArea() method to calculate area of rectangle
    @Override
    void printArea() {
        int area = dimension1 * dimension2; // Area = length * breadth
        System.out.println("Area of Rectangle: " + area);
    }
}

// Class for Triangle
class Triangle extends Shape {
    // Constructor
    public Triangle(int base, int height) {
        super(base, height);
    }

    // Override printArea() method to calculate area of triangle
    @Override
    void printArea() {
        double area = 0.5 * dimension1 * dimension2; // Area = 0.5 * base * height
        System.out.println("Area of Triangle: " + area);
    }
}

// Class for Circle
class Circle extends Shape {
    // Constructor
    public Circle(int radius) {
        super(radius, 0); // Set second dimension to 0, not needed for circle
    }

    // Override printArea() method to calculate area of circle
    @Override
    void printArea() {
        double area = Math.PI * dimension1 * dimension1; // Area = π * radius^2
        System.out.println("Area of Circle: " + area);
    }
}

// Main class to test the program
public class slip_22_1 {
    public static void main(String[] args) {
        // Create objects of each shape
        Shape rectangle = new Rectangle(5, 10); // Length = 5, Breadth = 10
        Shape triangle = new Triangle(6, 8); // Base = 6, Height = 8
        Shape circle = new Circle(7); // Radius = 7

        // Call printArea() for each shape
        rectangle.printArea();
        triangle.printArea();
        circle.printArea();
    }
}
