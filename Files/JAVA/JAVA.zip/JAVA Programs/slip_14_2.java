// Slip 14 :
// Q2
// Write a Java program to create a Package “SY” which has a class SYMarks (members –
// ComputerTotal, MathsTotal, and ElectronicsTotal). Create another package TY which has a
// class TYMarks (members – Theory, Practicals). Create ‘n’ objects of Student class (having
// rollNumber, name, SYMarks and TYMarks). Add the marks of SY and TY computer subjects
// and calculate the Grade (‘A’ for >= 70, ‘B’ for >= 60 ‘C’ for >= 50, Pass Class for > =40
// else‘FAIL’) and display the result of the student in proper format.

import SY.SYMarks;
import TY.TYMarks;
import java.util.Scanner;

public class slip_14_2 {
    private String rollNumber;
    private String name;
    private SYMarks syMarks;
    private TYMarks tyMarks;

    public slip_14_2(String rollNumber, String name, SYMarks syMarks, TYMarks tyMarks) {
        this.rollNumber = rollNumber;
        this.name = name;
        this.syMarks = syMarks;
        this.tyMarks = tyMarks;
    }

    public String calculateGrade() {
        int totalMarks = syMarks.getComputerTotal() + tyMarks.getTheory();
        if (totalMarks >= 70) return "A";
        else if (totalMarks >= 60) return "B";
        else if (totalMarks >= 50) return "C";
        else if (totalMarks >= 40) return "Pass Class";
        else return "FAIL";
    }

    public void displayResult() {
        System.out.println("Roll Number: " + rollNumber);
        System.out.println("Name: " + name);
        System.out.println("Grade: " + calculateGrade());
        System.out.println("----------------------------------");
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of students: ");
        int n = scanner.nextInt();
        scanner.nextLine(); 

        for (int i = 0; i < n; i++) {
            System.out.println("Enter details for student " + (i + 1) + ":");

            System.out.print("Roll Number: ");
            String rollNumber = scanner.nextLine();

            System.out.print("Name: ");
            String name = scanner.nextLine();

            System.out.print("Enter SY Computer Marks: ");
            int syComputer = scanner.nextInt();

            System.out.print("Enter SY Maths Marks: ");
            int syMaths = scanner.nextInt();

            System.out.print("Enter SY Electronics Marks: ");
            int syElectronics = scanner.nextInt();

            SYMarks syMarks = new SYMarks(syComputer, syMaths, syElectronics);

            System.out.print("Enter TY Theory Marks: ");
            int tyTheory = scanner.nextInt();

            System.out.print("Enter TY Practical Marks: ");
            int tyPracticals = scanner.nextInt();
            
            TYMarks tyMarks = new TYMarks(tyTheory, tyPracticals);

            slip_14_2 student = new slip_14_2(rollNumber, name, syMarks, tyMarks);
            student.displayResult();

            scanner.nextLine(); 
        }

        scanner.close(); 
    }
}

