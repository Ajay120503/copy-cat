import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class TemperatureConverter {
    private JFrame frame;
    private JTextField celsiusField;
    private JTextField fahrenheitField;
    private JButton convertButton;

    public TemperatureConverter() {
        // Initialize frame
        frame = new JFrame("Temperature Converter");
        frame.setSize(400, 300);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create Celsius label and text field
        JLabel celsiusLabel = new JLabel("Celsius:");
        celsiusLabel.setBounds(50, 50, 100, 30);
        frame.add(celsiusLabel);

        celsiusField = new JTextField();
        celsiusField.setBounds(150, 50, 100, 30);
        frame.add(celsiusField);

        // Create Fahrenheit label and text field
        JLabel fahrenheitLabel = new JLabel("Fahrenheit:");
        fahrenheitLabel.setBounds(50, 100, 100, 30);
        frame.add(fahrenheitLabel);

        fahrenheitField = new JTextField();
        fahrenheitField.setBounds(150, 100, 100, 30);
        fahrenheitField.setEditable(false); // Make it read-only
        frame.add(fahrenheitField);

        // Create Convert button
        convertButton = new JButton("Convert");
        convertButton.setBounds(150, 150, 100, 30);
        frame.add(convertButton);

        // Add action listener to the button
        convertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                convertTemperature(); // Call the conversion method
            }
        });

        // Set frame visibility
        frame.setVisible(true);
    }

    private void convertTemperature() {
        try {
            // Get the Celsius value from the text field
            double celsius = Double.parseDouble(celsiusField.getText());
            // Convert Celsius to Fahrenheit
            double fahrenheit = (celsius * 9 / 5) + 32;
            // Set the Fahrenheit value in the text field
            fahrenheitField.setText(String.format("%.1f", fahrenheit)); // Format to 1 decimal place
        } catch (NumberFormatException e) {
            // Handle invalid input
            JOptionPane.showMessageDialog(frame, "Please enter a valid number for Celsius.", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new TemperatureConverter(); // Create an instance of the TemperatureConverter
    }
}
